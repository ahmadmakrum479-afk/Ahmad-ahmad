# Cricket Manager — Full Tournament Management Android App

Complete Android Studio project built with **Kotlin 2.0**, **Jetpack Compose (Material 3)**, **Navigation Compose**, **Room Database (SQLite)**, **DataStore**, **WorkManager**, and **Firebase-ready Cloud Sync**.

## Included Features
- **Bilingual UI (বাংলা & English)**: Instant in-app language toggle.
- **16 Complete Screens**: Splash, Login/Sign Up, Home Dashboard, Create Tournament, My Tournaments, Tournament Details, Teams, Players, Match Schedule, Live Ball-by-Ball Scoring, Manual Scoring, Full Scorecard, NRR Points Table, Career Statistics & Leaderboards, User Permissions (Owner/Admin/Editor/Viewer + Codes + History), and Settings (JSON Backup/Restore + Sync).
- **2 Scoring Modes**:
  - **Ball-by-Ball Live Scoring**: Dot, 1, 2, 3, Four, Six, Wide, No-Ball, Bye, Leg-Bye, Wicket types, Strike Change, Batter/Bowler selection, Over Complete, Target & RRR, and **Undo Last Ball**.
  - **Manual Scoring**: Post-match runs, wickets, overs, extras, and Player of the Match entry.
- **Tournament Formats & Auto-NRR Points Table**: League, Round-Robin, Group Stage + Knockout, Semi-Final & Final generation, Played, Won, Lost, Draw/Abandoned, Points, Runs For, Runs Against, and exact Net Run Rate.
- **Offline-First**: Works without internet; includes JSON Backup/Restore and WorkManager background sync (plus optional Firebase Auth/Firestore bridge when `google-services.json` is added).

## How to Build Debug APK From Your Phone
1. Upload `CricketManager-Android.zip` to your GitHub repository.
2. Add `.github/workflows/build-apk.yml`.
3. Open **Actions** > download **Cricket-Manager-Debug-APK** > extract `app-debug.apk` > install on Android.
