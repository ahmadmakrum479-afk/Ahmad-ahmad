package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.MatchStage
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.AppLanguage
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.ui.theme.BoundaryCrimson
import com.cricketmanager.app.ui.theme.PitchEmerald
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MatchScheduleScreen(
    tournamentId: Long,
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onBack: () -> Unit,
    onOpenLiveScoring: (Long) -> Unit,
    onOpenManualScoring: (Long) -> Unit,
    onOpenScorecard: (Long) -> Unit
) {
    val strings = LocalAppStrings.current
    val isBn = strings.language == AppLanguage.BN
    val tournament = uiState.tournaments.firstOrNull { it.id == tournamentId }
    val teams = uiState.allTeams.filter { it.tournamentId == tournamentId }
    val matches = CricketStatsEngine.sortMatchesChronologically(
        uiState.allMatches.filter { it.tournamentId == tournamentId }
    )
    val perms = uiState.permissionsFor(tournamentId)

    var statusFilter by remember { mutableStateOf<MatchStatus?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingScheduleMatch by remember { mutableStateOf<MatchEntity?>(null) }
    var editScheduleError by remember { mutableStateOf<String?>(null) }

    val filtered = if (statusFilter == null) matches else matches.filter { it.status == statusFilter }

    Scaffold(
        topBar = { ScreenTopBar(title = strings.schedule, subtitle = "${filtered.size} Matches", onBack = onBack) },
        floatingActionButton = {
            if (perms.canEditSchedule && teams.size >= 2 && tournament != null) {
                FloatingActionButton(onClick = { showAddDialog = true }) {
                    Icon(Icons.Rounded.Add, contentDescription = strings.addMatch)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = statusFilter == null,
                        onClick = { statusFilter = null },
                        label = { Text("All") }
                    )
                    MatchStatus.entries.forEach { st ->
                        FilterChip(
                            selected = statusFilter == st,
                            onClick = { statusFilter = st },
                            label = { Text(st.labelEn) }
                        )
                    }
                }
            }

            items(filtered, key = { it.id }) { match ->
                Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Match #${match.matchNumber} · ${match.stage.labelEn} · ${match.groupName}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = match.status.labelEn,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (match.status == MatchStatus.LIVE) BoundaryCrimson else PitchEmerald
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(match.teamAName, fontWeight = FontWeight.SemiBold)
                            Text("${match.teamARuns}/${match.teamAWickets} (${CricketStatsEngine.formatOvers(match.teamABalls)})", fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(match.teamBName, fontWeight = FontWeight.SemiBold)
                            Text("${match.teamBRuns}/${match.teamBWickets} (${CricketStatsEngine.formatOvers(match.teamBBalls)})", fontWeight = FontWeight.Bold)
                        }
                        Text(
                            text = "${match.scheduledDate} · ${match.scheduledTime} · ${match.venue}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(match.resultSummary, style = MaterialTheme.typography.bodySmall)

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (perms.canScore && match.status != MatchStatus.COMPLETED && match.status != MatchStatus.ABANDONED && match.status != MatchStatus.WALKOVER) {
                                Button(
                                    onClick = { onOpenLiveScoring(match.id) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Live") }
                                OutlinedButton(
                                    onClick = { onOpenManualScoring(match.id) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Manual") }
                            } else if (perms.canScore) {
                                OutlinedButton(
                                    onClick = { onOpenManualScoring(match.id) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Edit") }
                            }
                            OutlinedButton(
                                onClick = { onOpenScorecard(match.id) },
                                modifier = Modifier.weight(1f)
                            ) { Text(strings.scorecard) }
                        }
                        if (perms.canEditSchedule) {
                            OutlinedButton(
                                onClick = {
                                    editScheduleError = null
                                    editingScheduleMatch = match
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (isBn) "তারিখ ও সময় বদলান" else "Edit Date & Time")
                            }
                        }
                        if (perms.canScore && match.status == MatchStatus.UPCOMING) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { viewModel.markMatchWalkover(match.id, match.teamAId) }) {
                                    Text("W/O: ${match.teamAName}")
                                }
                                TextButton(onClick = { viewModel.markMatchWalkover(match.id, match.teamBId) }) {
                                    Text("W/O: ${match.teamBName}")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog && tournament != null && teams.size >= 2) {
        var teamAId by remember { mutableStateOf(teams[0].id) }
        var teamBId by remember { mutableStateOf(teams[1].id) }
        var stage by remember { mutableStateOf(MatchStage.LEAGUE) }
        var venue by remember { mutableStateOf(tournament.location) }
        var date by remember { mutableStateOf(tournament.startDateLabel) }
        var time by remember { mutableStateOf("15:30") }
        var oversText by remember { mutableStateOf(tournament.oversPerMatch.toString()) }
        var scoringMode by remember { mutableStateOf(tournament.scoringMode) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(strings.addMatch) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Team A", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        teams.forEach { t ->
                            FilterChip(selected = teamAId == t.id, onClick = { teamAId = t.id }, label = { Text(t.shortCode) })
                        }
                    }
                    Text("Team B", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        teams.forEach { t ->
                            FilterChip(selected = teamBId == t.id, onClick = { teamBId = t.id }, label = { Text(t.shortCode) })
                        }
                    }
                    Text("Stage", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MatchStage.entries.forEach { st ->
                            FilterChip(selected = stage == st, onClick = { stage = st }, label = { Text(st.labelEn) })
                        }
                    }
                    Text("Scoring Mode", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ScoringMode.entries.forEach { sm ->
                            FilterChip(selected = scoringMode == sm, onClick = { scoringMode = sm }, label = { Text(sm.labelEn) })
                        }
                    }
                    OutlinedTextField(value = venue, onValueChange = { venue = it }, label = { Text("Venue") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Date") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Time") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    OutlinedTextField(
                        value = oversText,
                        onValueChange = { oversText = it.filter { c -> c.isDigit() } },
                        label = { Text("Overs") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val a = teams.firstOrNull { it.id == teamAId }
                        val b = teams.firstOrNull { it.id == teamBId }
                        if (a != null && b != null && a.id != b.id) {
                            viewModel.createMatch(
                                tournament, a, b, stage, stage.labelEn, venue, date, time,
                                oversText.toIntOrNull() ?: tournament.oversPerMatch, scoringMode
                            )
                            showAddDialog = false
                        }
                    }
                ) { Text(strings.save) }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text(strings.cancel) } }
        )
    }

    editingScheduleMatch?.let { targetMatch ->
        var dateInput by remember(targetMatch.id) { mutableStateOf(targetMatch.scheduledDate) }
        var timeInput by remember(targetMatch.id) { mutableStateOf(targetMatch.scheduledTime.ifBlank { "15:00" }) }

        AlertDialog(
            onDismissRequest = { editingScheduleMatch = null },
            title = {
                Text(if (isBn) "ম্যাচ #${targetMatch.matchNumber} তারিখ ও সময়" else "Edit Match #${targetMatch.matchNumber} Schedule")
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "${targetMatch.teamAName} vs ${targetMatch.teamBName}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedTextField(
                        value = dateInput,
                        onValueChange = { dateInput = it; editScheduleError = null },
                        label = { Text(if (isBn) "তারিখ (YYYY-MM-DD)" else "Date (YYYY-MM-DD)") },
                        placeholder = { Text("2026-11-10") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = timeInput,
                        onValueChange = { timeInput = it; editScheduleError = null },
                        label = { Text(if (isBn) "সময় (HH:mm)" else "Time (HH:mm)") },
                        placeholder = { Text("15:00") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = if (isBn) {
                            "বদলের পর শিডিউল তারিখ অনুযায়ী সাজবে ও লিগ ম্যাচ নম্বর তারিখ অনুসারে আপডেট হবে (ম্যাচের ID বদলাবে না)।"
                        } else {
                            "Schedule sorts by date and LEAGUE match numbers renumber chronologically (match ID stays unchanged)."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (editScheduleError != null) {
                        Text(
                            text = editScheduleError!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateMatchSchedule(
                            matchId = targetMatch.id,
                            scheduledDate = dateInput,
                            scheduledTime = timeInput,
                            onError = { editScheduleError = it },
                            onSaved = { editingScheduleMatch = null }
                        )
                    }
                ) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { editingScheduleMatch = null }) { Text(strings.cancel) }
            }
        )
    }
}
