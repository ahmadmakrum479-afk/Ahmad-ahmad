package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.ui.theme.PitchEmerald
import com.cricketmanager.app.viewmodel.CricketUiState

@Composable
fun PointsTableScreen(
    tournamentId: Long,
    uiState: CricketUiState,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val tournament = uiState.tournaments.firstOrNull { it.id == tournamentId } ?: uiState.selectedTournament
    val tId = tournament?.id ?: tournamentId
    val teams = uiState.allTeams.filter { it.tournamentId == tId }
    val tMatches = uiState.allMatches.filter { it.tournamentId == tId }
    val groups = teams.map { it.groupName.ifBlank { "Group A" } }.distinct()
    var selectedGroup by remember { mutableStateOf<String?>(null) }

    val sortedTeams = CricketStatsEngine.sortTeamsForPointsTable(
        teams = if (selectedGroup == null) teams else teams.filter { it.groupName == selectedGroup },
        matches = tMatches,
        tiebreakerOrder = tournament?.tiebreakerOrder ?: "POINTS,WINS,NRR,H2H,NAME"
    )

    Scaffold(
        topBar = {
            ScreenTopBar(
                title = strings.pointsTable,
                subtitle = tournament?.name,
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (groups.size > 1) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = selectedGroup == null,
                                onClick = { selectedGroup = null },
                                label = { Text("All Groups") }
                            )
                        }
                        items(groups) { g ->
                            FilterChip(
                                selected = selectedGroup == g,
                                onClick = { selectedGroup = g },
                                label = { Text(g) }
                            )
                        }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Text("#", modifier = Modifier.weight(0.4f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            Text("Team", modifier = Modifier.weight(2.0f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            Text("P", modifier = Modifier.weight(0.5f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            Text("W", modifier = Modifier.weight(0.5f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            Text("L", modifier = Modifier.weight(0.5f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            Text("Pts", modifier = Modifier.weight(0.6f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            Text("NRR", modifier = Modifier.weight(1.1f), textAlign = TextAlign.End, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                        HorizontalDivider()
                    }
                }
            }

            itemsIndexed(sortedTeams, key = { _, t -> t.id }) { index, team ->
                val nrr = CricketStatsEngine.calculateNetRunRate(
                    team.runsFor, team.ballsFaced, team.runsAgainst, team.ballsBowled
                )
                Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text("${index + 1}", modifier = Modifier.weight(0.4f), fontWeight = FontWeight.Bold)
                            Text("${team.logoEmoji} ${team.shortCode}", modifier = Modifier.weight(2.0f), fontWeight = FontWeight.Bold)
                            Text("${team.played}", modifier = Modifier.weight(0.5f), textAlign = TextAlign.Center)
                            Text("${team.won}", modifier = Modifier.weight(0.5f), textAlign = TextAlign.Center)
                            Text("${team.lost}", modifier = Modifier.weight(0.5f), textAlign = TextAlign.Center)
                            Text("${team.points}", modifier = Modifier.weight(0.6f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = PitchEmerald)
                            Text(CricketStatsEngine.formatNrr(nrr), modifier = Modifier.weight(1.1f), textAlign = TextAlign.End, fontWeight = FontWeight.SemiBold)
                        }
                        Text(
                            text = "${team.name} (${team.groupName}) · RF: ${team.runsFor} (${CricketStatsEngine.formatOvers(team.ballsFaced)}) · RA: ${team.runsAgainst} (${CricketStatsEngine.formatOvers(team.ballsBowled)}) · D/A: ${team.tiedOrAbandoned}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
