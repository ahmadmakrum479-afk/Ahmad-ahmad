package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onAuthenticated: () -> Unit
) {
    val strings = LocalAppStrings.current
    var isSignUp by remember { mutableStateOf(false) }
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var organization by remember { mutableStateOf("") }
    var viewerCodeInput by remember { mutableStateOf("") }
    var authInlineError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "🏏 ${strings.appTitle}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            TextButton(
                onClick = { viewModel.setLanguage(if (uiState.languageCode == "BN") "EN" else "BN") }
            ) {
                Text(if (uiState.languageCode == "BN") "English" else "বাংলা")
            }
        }

        Spacer(Modifier.height(12.dp))

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = if (isSignUp) strings.signUpTitle else strings.loginTitle,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = !isSignUp,
                        onClick = { isSignUp = false; authInlineError = null },
                        shape = SegmentedButtonDefaults.itemShape(0, 2)
                    ) { Text(strings.loginBtn) }
                    SegmentedButton(
                        selected = isSignUp,
                        onClick = { isSignUp = true; authInlineError = null },
                        shape = SegmentedButtonDefaults.itemShape(1, 2)
                    ) { Text(strings.signUpBtn) }
                }

                if (isSignUp) {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text(strings.fullName) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = organization,
                        onValueChange = { organization = it },
                        label = { Text(strings.organization) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it; authInlineError = null },
                    label = { Text(strings.email) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; authInlineError = null },
                    label = { Text(if (isSignUp) "${strings.password} (৬+ অক্ষর)" else strings.password) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    isError = isSignUp && password.isNotEmpty() && password.trim().length < 6,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (authInlineError != null) {
                    Text(
                        text = authInlineError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = {
                        if (isSignUp) {
                            if (password.trim().length < 6) {
                                authInlineError = "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।"
                            } else {
                                authInlineError = null
                                viewModel.signUp(fullName, email, password, organization, onAuthenticated)
                            }
                        } else {
                            authInlineError = null
                            viewModel.login(email, password, onAuthenticated)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text(if (isSignUp) strings.signUpBtn else strings.loginBtn)
                }

                OutlinedButton(
                    onClick = { viewModel.continueAsGuest(onAuthenticated) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text(strings.guestContinueBtn)
                }

                Text(
                    text = if (uiState.languageCode == "BN") "অ্যাকাউন্ট ছাড়াই দর্শক কোড দিয়ে দেখুন" else "Watch without an account (Viewer Code)",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = viewerCodeInput,
                        onValueChange = { viewerCodeInput = it.uppercase() },
                        label = { Text(if (uiState.languageCode == "BN") "দর্শক কোড (VW...)" else "Viewer Code") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Button(
                        onClick = { viewModel.joinAsGuestViewerByCode(viewerCodeInput, onAuthenticated) },
                        enabled = viewerCodeInput.trim().isNotEmpty()
                    ) {
                        Text(if (uiState.languageCode == "BN") "দেখুন" else "Watch")
                    }
                }
            }
        }
    }
}
