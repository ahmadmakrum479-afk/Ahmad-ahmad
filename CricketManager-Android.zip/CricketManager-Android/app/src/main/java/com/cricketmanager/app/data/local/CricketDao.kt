package com.cricketmanager.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.cricketmanager.app.domain.CricketStatsEngine
import kotlinx.coroutines.flow.Flow

@Dao
interface CricketDao {

    @Query("SELECT * FROM users ORDER BY id ASC")
    fun observeAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: Long): UserEntity?

    @Query("SELECT * FROM users ORDER BY id ASC LIMIT 1")
    suspend fun getFirstUser(): UserEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: UserEntity): Long

    @Query("SELECT * FROM tournaments ORDER BY updatedAt DESC")
    fun observeAllTournaments(): Flow<List<TournamentEntity>>

    @Query("SELECT * FROM tournaments ORDER BY updatedAt DESC")
    suspend fun getAllTournamentsOnce(): List<TournamentEntity>

    @Query("SELECT * FROM tournaments WHERE id = :id LIMIT 1")
    suspend fun getTournamentById(id: Long): TournamentEntity?

    @Query(
        "SELECT * FROM tournaments WHERE UPPER(tournamentCode) = UPPER(:code) OR UPPER(editorCode) = UPPER(:code) OR UPPER(viewerCode) = UPPER(:code) LIMIT 1"
    )
    suspend fun findTournamentByAnyCode(code: String): TournamentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTournament(tournament: TournamentEntity): Long

    @Update
    suspend fun updateTournament(tournament: TournamentEntity)

    @Query("DELETE FROM tournaments WHERE id = :tournamentId")
    suspend fun deleteTournament(tournamentId: Long)

    @Query("SELECT * FROM teams ORDER BY id ASC")
    fun observeAllTeams(): Flow<List<TeamEntity>>

    @Query("SELECT * FROM teams WHERE tournamentId = :tournamentId")
    suspend fun getTeamsByTournamentOnce(tournamentId: Long): List<TeamEntity>

    @Query("SELECT * FROM teams WHERE id = :teamId LIMIT 1")
    suspend fun getTeamById(teamId: Long): TeamEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeam(team: TeamEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeams(teams: List<TeamEntity>): List<Long>

    @Update
    suspend fun updateTeam(team: TeamEntity)

    @Query("DELETE FROM teams WHERE id = :teamId")
    suspend fun deleteTeam(teamId: Long)

    @Query("SELECT * FROM players ORDER BY runsScored DESC, wicketsTaken DESC, name ASC")
    fun observeAllPlayers(): Flow<List<PlayerEntity>>

    @Query("SELECT * FROM players WHERE tournamentId = :tournamentId")
    suspend fun getPlayersByTournamentOnce(tournamentId: Long): List<PlayerEntity>

    @Query("SELECT * FROM players WHERE teamId = :teamId ORDER BY jerseyNumber ASC")
    suspend fun getPlayersByTeamOnce(teamId: Long): List<PlayerEntity>

    @Query("SELECT * FROM players WHERE id = :playerId LIMIT 1")
    suspend fun getPlayerById(playerId: Long): PlayerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: PlayerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayers(players: List<PlayerEntity>)

    @Update
    suspend fun updatePlayer(player: PlayerEntity)

    @Query("DELETE FROM players WHERE id = :playerId")
    suspend fun deletePlayer(playerId: Long)

    @Query("SELECT * FROM matches ORDER BY tournamentId ASC, scheduledDate ASC, scheduledTime ASC, matchNumber ASC, id ASC")
    fun observeAllMatches(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM matches WHERE tournamentId = :tournamentId ORDER BY scheduledDate ASC, scheduledTime ASC, matchNumber ASC, id ASC")
    suspend fun getMatchesByTournamentOnce(tournamentId: Long): List<MatchEntity>

    @Query("SELECT * FROM matches WHERE id = :matchId LIMIT 1")
    suspend fun getMatchById(matchId: Long): MatchEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: MatchEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatches(matches: List<MatchEntity>)

    @Update
    suspend fun updateMatch(match: MatchEntity)

    @Query("DELETE FROM matches WHERE id = :matchId")
    suspend fun deleteMatch(matchId: Long)

    @Query("SELECT * FROM ball_events ORDER BY matchId ASC, innings ASC, sequenceNumber ASC, id ASC")
    fun observeAllBallEvents(): Flow<List<BallEventEntity>>

    @Query("SELECT * FROM ball_events WHERE matchId = :matchId ORDER BY innings ASC, sequenceNumber ASC, id ASC")
    suspend fun getBallEventsForMatchOnce(matchId: Long): List<BallEventEntity>

    @Query("SELECT * FROM ball_events WHERE matchId = :matchId AND innings = :innings ORDER BY sequenceNumber DESC, id DESC LIMIT 1")
    suspend fun getLastBallInInnings(matchId: Long, innings: Int): BallEventEntity?

    @Query("SELECT * FROM ball_events WHERE id = :ballId LIMIT 1")
    suspend fun getBallById(ballId: Long): BallEventEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBallEvent(ball: BallEventEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBallEvents(balls: List<BallEventEntity>)

    @Update
    suspend fun updateBallEvent(ball: BallEventEntity)

    @Query("DELETE FROM ball_events WHERE id = :ballId")
    suspend fun deleteBallEvent(ballId: Long)

    @Query("SELECT * FROM tournament_members ORDER BY joinedAt ASC")
    fun observeAllMembers(): Flow<List<TournamentMemberEntity>>

    @Query("SELECT * FROM tournament_members WHERE tournamentId = :tournamentId")
    suspend fun getMembersByTournamentOnce(tournamentId: Long): List<TournamentMemberEntity>

    @Query("SELECT * FROM tournament_members WHERE tournamentId = :tournamentId AND userId = :userId LIMIT 1")
    suspend fun getMember(tournamentId: Long, userId: Long): TournamentMemberEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: TournamentMemberEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMembers(members: List<TournamentMemberEntity>)

    @Update
    suspend fun updateMember(member: TournamentMemberEntity)

    @Query("DELETE FROM tournament_members WHERE id = :memberId")
    suspend fun deleteMember(memberId: Long)

    @Query("SELECT * FROM audit_logs ORDER BY createdAt DESC LIMIT 200")
    fun observeAllAuditLogs(): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_logs WHERE tournamentId = :tournamentId ORDER BY createdAt DESC")
    suspend fun getAuditLogsOnce(tournamentId: Long): List<AuditLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLogs(logs: List<AuditLogEntity>)

    @Query("SELECT * FROM player_match_stats ORDER BY matchId ASC, innings ASC, id ASC")
    fun observeAllPlayerMatchStats(): Flow<List<PlayerMatchStatEntity>>

    @Query("SELECT * FROM player_match_stats WHERE matchId = :matchId ORDER BY innings ASC, id ASC")
    suspend fun getPlayerMatchStatsOnce(matchId: Long): List<PlayerMatchStatEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayerMatchStats(stats: List<PlayerMatchStatEntity>)

    @Query("DELETE FROM player_match_stats WHERE matchId = :matchId")
    suspend fun deletePlayerMatchStatsForMatch(matchId: Long)

    @Query("SELECT COUNT(*) FROM tournaments")
    suspend fun countTournaments(): Int

    @Transaction
    suspend fun recordBallAndApplyStats(
        matchId: Long,
        strikerId: Long,
        nonStrikerId: Long,
        bowlerId: Long,
        runsOffBat: Int,
        extraRuns: Int,
        extraType: ExtraType,
        isWicket: Boolean,
        wicketType: WicketType,
        dismissedPlayerId: Long,
        manualStrikeSwap: Boolean = false
    ) {
        val match = getMatchById(matchId) ?: return
        val isLegalBall = CricketStatsEngine.isLegalDelivery(extraType)
        val totalRunsForBall = runsOffBat + extraRuns

        val currentInnings = match.currentInnings
        val firstBatIsB = match.battingFirstTeamId == match.teamBId
        val battingTeamIsA = if (currentInnings == 1) !firstBatIsB else firstBatIsB
        val prevBalls = if (battingTeamIsA) match.teamABalls else match.teamBBalls
        val nextLegalBalls = prevBalls + if (isLegalBall) 1 else 0
        val overNum = prevBalls / 6
        val ballInOver = if (isLegalBall) (prevBalls % 6) + 1 else (prevBalls % 6)

        val existingEvents = getBallEventsForMatchOnce(matchId).filter { it.innings == currentInnings }
        val nextSeq = (existingEvents.maxOfOrNull { it.sequenceNumber } ?: 0) + 1

        val label = CricketStatsEngine.formatBallChip(
            runsOffBat = runsOffBat,
            extraRuns = extraRuns,
            extraType = extraType,
            isWicket = isWicket
        )

        insertBallEvent(
            BallEventEntity(
                tournamentId = match.tournamentId,
                matchId = matchId,
                innings = currentInnings,
                sequenceNumber = nextSeq,
                overNumber = overNum,
                ballInOver = ballInOver,
                strikerId = strikerId,
                nonStrikerId = nonStrikerId,
                bowlerId = bowlerId,
                runsOffBat = runsOffBat,
                extraRuns = extraRuns,
                extraType = extraType,
                isWicket = isWicket,
                wicketType = wicketType,
                dismissedPlayerId = if (isWicket) dismissedPlayerId else 0L,
                isBoundaryFour = runsOffBat == 4,
                isBoundarySix = runsOffBat == 6,
                summaryLabel = label
            )
        )

        // Update Striker Batting Career Stats
        if (strikerId > 0L) {
            getPlayerById(strikerId)?.let { batter ->
                val batterBalls = if (extraType != ExtraType.WIDE) 1 else 0
                updatePlayer(
                    batter.copy(
                        runsScored = batter.runsScored + runsOffBat,
                        ballsFaced = batter.ballsFaced + batterBalls,
                        fours = batter.fours + if (runsOffBat == 4) 1 else 0,
                        sixes = batter.sixes + if (runsOffBat == 6) 1 else 0
                    )
                )
            }
        }

        // Update Bowler Bowling Career Stats
        if (bowlerId > 0L) {
            getPlayerById(bowlerId)?.let { bowler ->
                val bowlerConceded = when (extraType) {
                    ExtraType.BYE, ExtraType.LEG_BYE -> 0
                    else -> runsOffBat + extraRuns
                }
                val countsAsWicket = isWicket && wicketType != WicketType.RUN_OUT
                updatePlayer(
                    bowler.copy(
                        ballsBowled = bowler.ballsBowled + if (isLegalBall) 1 else 0,
                        runsConceded = bowler.runsConceded + bowlerConceded,
                        wicketsTaken = bowler.wicketsTaken + if (countsAsWicket) 1 else 0
                    )
                )
            }
        }

        // Strike rotation check
        var nextStriker = strikerId
        var nextNonStriker = nonStrikerId
        val oddRuns = (runsOffBat + if (extraType == ExtraType.BYE || extraType == ExtraType.LEG_BYE) extraRuns else 0) % 2 == 1
        if (oddRuns) {
            val tmp = nextStriker
            nextStriker = nextNonStriker
            nextNonStriker = tmp
        }
        val overJustCompleted = isLegalBall && nextLegalBalls > 0 && nextLegalBalls % 6 == 0
        if (overJustCompleted || manualStrikeSwap) {
            val tmp = nextStriker
            nextStriker = nextNonStriker
            nextNonStriker = tmp
        }
        if (isWicket && dismissedPlayerId > 0L) {
            if (nextStriker == dismissedPlayerId) nextStriker = 0L
            if (nextNonStriker == dismissedPlayerId) nextNonStriker = 0L
        }

        val resolvedFirstBat = if (match.battingFirstTeamId > 0L) match.battingFirstTeamId else match.teamAId
        val firstInningsRuns = if (firstBatIsB) match.teamBRuns else match.teamARuns
        val updatedMatch = if (battingTeamIsA) {
            val newRuns = match.teamARuns + totalRunsForBall
            val summaryText = if (currentInnings == 1) {
                "1st Innings Live"
            } else {
                val need = ((firstInningsRuns + 1) - newRuns).coerceAtLeast(0)
                if (need == 0) "Target reached!" else "Need $need runs to win"
            }
            match.copy(
                status = MatchStatus.LIVE,
                battingFirstTeamId = resolvedFirstBat,
                teamARuns = newRuns,
                teamAWickets = match.teamAWickets + if (isWicket) 1 else 0,
                teamABalls = nextLegalBalls,
                teamAExtras = match.teamAExtras + extraRuns,
                activeStrikerId = nextStriker,
                activeNonStrikerId = nextNonStriker,
                activeBowlerId = bowlerId,
                resultSummary = summaryText,
                updatedAt = System.currentTimeMillis()
            )
        } else {
            val newRuns = match.teamBRuns + totalRunsForBall
            val summaryText = if (currentInnings == 1) {
                "1st Innings Live"
            } else {
                val need = ((firstInningsRuns + 1) - newRuns).coerceAtLeast(0)
                if (need == 0) "Target reached!" else "Need $need runs to win"
            }
            match.copy(
                status = MatchStatus.LIVE,
                battingFirstTeamId = resolvedFirstBat,
                teamBRuns = newRuns,
                teamBWickets = match.teamBWickets + if (isWicket) 1 else 0,
                teamBBalls = nextLegalBalls,
                teamBExtras = match.teamBExtras + extraRuns,
                activeStrikerId = nextStriker,
                activeNonStrikerId = nextNonStriker,
                activeBowlerId = bowlerId,
                resultSummary = summaryText,
                updatedAt = System.currentTimeMillis()
            )
        }
        updateMatch(updatedMatch)
    }

    @Transaction
    suspend fun undoLastBallInMatch(matchId: Long) {
        val match = getMatchById(matchId) ?: return
        val lastBall = getLastBallInInnings(matchId, match.currentInnings) ?: return
        val isLegalBall = CricketStatsEngine.isLegalDelivery(lastBall.extraType)
        val totalRunsForBall = lastBall.runsOffBat + lastBall.extraRuns

        if (lastBall.strikerId > 0L) {
            getPlayerById(lastBall.strikerId)?.let { batter ->
                val batterBalls = if (lastBall.extraType != ExtraType.WIDE) 1 else 0
                updatePlayer(
                    batter.copy(
                        runsScored = (batter.runsScored - lastBall.runsOffBat).coerceAtLeast(0),
                        ballsFaced = (batter.ballsFaced - batterBalls).coerceAtLeast(0),
                        fours = (batter.fours - if (lastBall.runsOffBat == 4) 1 else 0).coerceAtLeast(0),
                        sixes = (batter.sixes - if (lastBall.runsOffBat == 6) 1 else 0).coerceAtLeast(0)
                    )
                )
            }
        }

        if (lastBall.bowlerId > 0L) {
            getPlayerById(lastBall.bowlerId)?.let { bowler ->
                val bowlerConceded = when (lastBall.extraType) {
                    ExtraType.BYE, ExtraType.LEG_BYE -> 0
                    else -> lastBall.runsOffBat + lastBall.extraRuns
                }
                val countsAsWicket = lastBall.isWicket && lastBall.wicketType != WicketType.RUN_OUT
                updatePlayer(
                    bowler.copy(
                        ballsBowled = (bowler.ballsBowled - if (isLegalBall) 1 else 0).coerceAtLeast(0),
                        runsConceded = (bowler.runsConceded - bowlerConceded).coerceAtLeast(0),
                        wicketsTaken = (bowler.wicketsTaken - if (countsAsWicket) 1 else 0).coerceAtLeast(0)
                    )
                )
            }
        }

        deleteBallEvent(lastBall.id)

        val firstBatIsB = match.battingFirstTeamId == match.teamBId
        val battingTeamIsA = if (lastBall.innings == 1) !firstBatIsB else firstBatIsB
        val revertedMatch = if (battingTeamIsA) {
            match.copy(
                teamARuns = (match.teamARuns - totalRunsForBall).coerceAtLeast(0),
                teamAWickets = (match.teamAWickets - if (lastBall.isWicket) 1 else 0).coerceAtLeast(0),
                teamABalls = (match.teamABalls - if (isLegalBall) 1 else 0).coerceAtLeast(0),
                teamAExtras = (match.teamAExtras - lastBall.extraRuns).coerceAtLeast(0),
                activeStrikerId = lastBall.strikerId,
                activeNonStrikerId = lastBall.nonStrikerId,
                activeBowlerId = lastBall.bowlerId,
                updatedAt = System.currentTimeMillis()
            )
        } else {
            match.copy(
                teamBRuns = (match.teamBRuns - totalRunsForBall).coerceAtLeast(0),
                teamBWickets = (match.teamBWickets - if (lastBall.isWicket) 1 else 0).coerceAtLeast(0),
                teamBBalls = (match.teamBBalls - if (isLegalBall) 1 else 0).coerceAtLeast(0),
                teamBExtras = (match.teamBExtras - lastBall.extraRuns).coerceAtLeast(0),
                activeStrikerId = lastBall.strikerId,
                activeNonStrikerId = lastBall.nonStrikerId,
                activeBowlerId = lastBall.bowlerId,
                updatedAt = System.currentTimeMillis()
            )
        }
        updateMatch(revertedMatch)
    }

    @Transaction
    suspend fun recalculateTournamentStandings(tournamentId: Long) {
        val tournament = getTournamentById(tournamentId) ?: return
        val teams = getTeamsByTournamentOnce(tournamentId)
        val matches = getMatchesByTournamentOnce(tournamentId)
        val updatedTeams = CricketStatsEngine.computeTeamStandings(
            teams = teams,
            matches = matches,
            tournament = tournament,
            allOutWickets = tournament.allOutWickets.coerceAtLeast(1)
        )
        for (updatedTeam in updatedTeams) {
            updateTeam(updatedTeam)
        }
    }

    @Transaction
    suspend fun rebuildTournamentPlayerStats(tournamentId: Long) {
        val players = getPlayersByTournamentOnce(tournamentId)
        if (players.isEmpty()) return
        val matches = getMatchesByTournamentOnce(tournamentId)
        val completedMatches = matches.filter { it.status == MatchStatus.COMPLETED }
        val liveMatches = matches.filter { it.status == MatchStatus.LIVE }

        val matchStatsByMatchId = mutableMapOf<Long, List<PlayerMatchStatEntity>>()
        for (m in completedMatches) {
            val savedStats = getPlayerMatchStatsOnce(m.id)
            if (savedStats.isNotEmpty()) {
                matchStatsByMatchId[m.id] = savedStats
            } else {
                val balls = getBallEventsForMatchOnce(m.id)
                if (balls.isNotEmpty()) {
                    matchStatsByMatchId[m.id] = CricketStatsEngine.buildMatchStatsFromBallEvents(m, players, balls)
                }
            }
        }

        val liveBallsByMatchId = mutableMapOf<Long, List<BallEventEntity>>()
        for (m in liveMatches) {
            val balls = getBallEventsForMatchOnce(m.id)
            if (balls.isNotEmpty()) {
                liveBallsByMatchId[m.id] = balls
            }
        }

        val rebuiltPlayers = CricketStatsEngine.aggregatePlayerCareerStats(
            players = players,
            completedMatches = completedMatches,
            matchStatsByMatchId = matchStatsByMatchId,
            liveBallsByMatchId = liveBallsByMatchId
        )
        for (p in rebuiltPlayers) {
            updatePlayer(p)
        }
    }

    @Transaction
    suspend fun finalizeMatch(
        matchId: Long,
        playerOfMatchId: Long,
        playerOfMatchName: String,
        isAbandoned: Boolean = false,
        superOverWinnerTeamId: Long = 0L
    ) {
        val match = getMatchById(matchId) ?: return
        val tournament = getTournamentById(match.tournamentId)
        val allOutLimit = CricketStatsEngine.effectiveAllOutForMatch(match, tournament)
        val resolvedFirstBatId = if (match.battingFirstTeamId == match.teamBId) match.teamBId else match.teamAId
        val (winnerId, summary) = CricketStatsEngine.resolveMatchOutcome(
            teamAId = match.teamAId,
            teamAName = match.teamAName,
            teamARuns = match.teamARuns,
            teamAWickets = match.teamAWickets,
            teamBId = match.teamBId,
            teamBName = match.teamBName,
            teamBRuns = match.teamBRuns,
            teamBWickets = match.teamBWickets,
            battingFirstTeamId = resolvedFirstBatId,
            allOutWickets = allOutLimit,
            isAbandoned = isAbandoned,
            tieRule = tournament?.tieRule ?: TieRule.SHARE_POINTS,
            superOverWinnerTeamId = superOverWinnerTeamId
        )

        val balls = getBallEventsForMatchOnce(matchId)
        val tournamentPlayers = getPlayersByTournamentOnce(match.tournamentId)
        val summaryRows = CricketStatsEngine.buildMatchStatsFromBallEvents(
            match = match.copy(battingFirstTeamId = resolvedFirstBatId),
            players = tournamentPlayers,
            balls = balls
        )

        val resolvedPomPair = when {
            isAbandoned -> 0L to ""
            playerOfMatchId > 0L -> playerOfMatchId to playerOfMatchName
            else -> {
                val autoStat = CricketStatsEngine.pickAutoManOfTheMatch(summaryRows, winnerId, tournament)?.first
                if (autoStat != null) {
                    autoStat.playerId to autoStat.playerName
                } else {
                    val fallback = tournamentPlayers.firstOrNull { it.teamId == winnerId }
                        ?: tournamentPlayers.firstOrNull { it.teamId == match.teamAId || it.teamId == match.teamBId }
                    (fallback?.id ?: 0L) to (fallback?.name ?: "")
                }
            }
        }
        val resolvedPomId = resolvedPomPair.first
        val resolvedPomName = resolvedPomPair.second

        updateMatch(
            match.copy(
                status = if (isAbandoned) MatchStatus.ABANDONED else MatchStatus.COMPLETED,
                battingFirstTeamId = resolvedFirstBatId,
                winnerTeamId = winnerId,
                playerOfMatchId = resolvedPomId,
                playerOfMatchName = resolvedPomName,
                resultSummary = summary,
                updatedAt = System.currentTimeMillis()
            )
        )

        if (summaryRows.isNotEmpty()) {
            deletePlayerMatchStatsForMatch(matchId)
            insertPlayerMatchStats(summaryRows)
        } else if (isAbandoned) {
            deletePlayerMatchStatsForMatch(matchId)
        }

        rebuildTournamentPlayerStats(match.tournamentId)
        recalculateTournamentStandings(match.tournamentId)
    }

    @Transaction
    suspend fun submitManualMatchScore(
        matchId: Long,
        teamARuns: Int,
        teamAWickets: Int,
        teamABalls: Int,
        teamAExtras: Int,
        teamBRuns: Int,
        teamBWickets: Int,
        teamBBalls: Int,
        teamBExtras: Int,
        playerStats: List<PlayerMatchStatEntity>,
        playerOfMatchId: Long,
        playerOfMatchName: String,
        customResultText: String,
        battingFirstTeamId: Long = 0L,
        teamAPlayingIds: String? = null,
        teamBPlayingIds: String? = null,
        superOverWinnerTeamId: Long = 0L
    ) {
        val match = getMatchById(matchId) ?: return
        val tournament = getTournamentById(match.tournamentId)
        val allOutLimit = CricketStatsEngine.effectiveAllOutForMatch(match, tournament)
        val resolvedAPlaying = teamAPlayingIds ?: match.teamAPlayingIds
        val resolvedBPlaying = teamBPlayingIds ?: match.teamBPlayingIds
        val resolvedFirstBatId = when {
            battingFirstTeamId == match.teamAId || battingFirstTeamId == match.teamBId -> battingFirstTeamId
            match.battingFirstTeamId == match.teamBId -> match.teamBId
            else -> match.teamAId
        }
        val (winnerId, autoSummary) = CricketStatsEngine.resolveMatchOutcome(
            teamAId = match.teamAId,
            teamAName = match.teamAName,
            teamARuns = teamARuns,
            teamAWickets = teamAWickets,
            teamBId = match.teamBId,
            teamBName = match.teamBName,
            teamBRuns = teamBRuns,
            teamBWickets = teamBWickets,
            battingFirstTeamId = resolvedFirstBatId,
            allOutWickets = allOutLimit,
            isAbandoned = false,
            tieRule = tournament?.tieRule ?: TieRule.SHARE_POINTS,
            superOverWinnerTeamId = superOverWinnerTeamId
        )
        val summary = customResultText.ifBlank { autoSummary }

        val resolvedPom = if (playerOfMatchId > 0L) {
            playerOfMatchId to playerOfMatchName
        } else {
            val autoStat = CricketStatsEngine.pickAutoManOfTheMatch(playerStats, winnerId, tournament)?.first
            if (autoStat != null) autoStat.playerId to autoStat.playerName else 0L to ""
        }
        val finalPomId = resolvedPom.first
        val finalPomName = resolvedPom.second

        updateMatch(
            match.copy(
                status = MatchStatus.COMPLETED,
                scoringMode = ScoringMode.MANUAL,
                battingFirstTeamId = resolvedFirstBatId,
                teamARuns = teamARuns,
                teamAWickets = teamAWickets,
                teamABalls = teamABalls,
                teamAExtras = teamAExtras,
                teamBRuns = teamBRuns,
                teamBWickets = teamBWickets,
                teamBBalls = teamBBalls,
                teamBExtras = teamBExtras,
                teamAPlayingIds = resolvedAPlaying,
                teamBPlayingIds = resolvedBPlaying,
                winnerTeamId = winnerId,
                playerOfMatchId = finalPomId,
                playerOfMatchName = finalPomName,
                resultSummary = summary,
                updatedAt = System.currentTimeMillis()
            )
        )

        deletePlayerMatchStatsForMatch(matchId)
        val nonEmptyStats = playerStats.filter {
            it.didBat || it.didBowl || it.runsScored > 0 || it.ballsFaced > 0 || it.ballsBowled > 0 || it.wicketsTaken > 0
        }.toMutableList()
        val existingPlayerIds = nonEmptyStats.map { it.playerId }.toSet()
        val selectedPlayingIds = (CricketStatsEngine.parsePlayingIds(resolvedAPlaying) +
            CricketStatsEngine.parsePlayingIds(resolvedBPlaying)).toSet()
        if (selectedPlayingIds.isNotEmpty()) {
            val tournamentPlayers = getPlayersByTournamentOnce(match.tournamentId).associateBy { it.id }
            for (pid in selectedPlayingIds) {
                if (pid !in existingPlayerIds) {
                    val p = tournamentPlayers[pid] ?: continue
                    nonEmptyStats.add(
                        PlayerMatchStatEntity(
                            tournamentId = match.tournamentId,
                            matchId = matchId,
                            teamId = p.teamId,
                            playerId = p.id,
                            playerName = p.name,
                            innings = if (p.teamId == resolvedFirstBatId) 1 else 2,
                            didBat = false,
                            didBowl = false
                        )
                    )
                }
            }
        }
        if (nonEmptyStats.isNotEmpty()) {
            insertPlayerMatchStats(nonEmptyStats.map { it.copy(id = 0, matchId = matchId, tournamentId = match.tournamentId) })
        }

        rebuildTournamentPlayerStats(match.tournamentId)
        recalculateTournamentStandings(match.tournamentId)
    }

    @Transaction
    suspend fun updateMatchDateTimeAndRenumber(
        matchId: Long,
        scheduledDate: String,
        scheduledTime: String
    ) {
        val target = getMatchById(matchId) ?: return
        updateMatch(
            target.copy(
                scheduledDate = scheduledDate.trim(),
                scheduledTime = scheduledTime.trim(),
                updatedAt = System.currentTimeMillis()
            )
        )
        val allMatches = getMatchesByTournamentOnce(target.tournamentId)
        val renumbered = CricketStatsEngine.renumberLeagueMatchesByDate(allMatches)
        val existingById = allMatches.associateBy { it.id }
        for (updated in renumbered) {
            val prev = existingById[updated.id]
            if (prev != null && prev.matchNumber != updated.matchNumber) {
                updateMatch(updated.copy(updatedAt = System.currentTimeMillis()))
            }
        }
    }

    @Transaction
    suspend fun updateMatchPlayingSquadAndSyncStats(
        matchId: Long,
        teamAPlayingIds: String,
        teamBPlayingIds: String
    ) {
        val match = getMatchById(matchId) ?: return
        val firstBatId = if (match.battingFirstTeamId == match.teamBId) match.teamBId else match.teamAId
        updateMatch(
            match.copy(
                teamAPlayingIds = teamAPlayingIds,
                teamBPlayingIds = teamBPlayingIds,
                updatedAt = System.currentTimeMillis()
            )
        )
        if (match.status == MatchStatus.COMPLETED) {
            val selectedIds = (CricketStatsEngine.parsePlayingIds(teamAPlayingIds) +
                CricketStatsEngine.parsePlayingIds(teamBPlayingIds)).toSet()
            val existingStats = getPlayerMatchStatsOnce(matchId)
            val keptStats = existingStats.filter { st ->
                val hasPerf = st.didBat || st.didBowl || st.runsScored > 0 || st.ballsFaced > 0 ||
                    st.ballsBowled > 0 || st.runsConceded > 0 || st.wicketsTaken > 0
                hasPerf || st.playerId in selectedIds
            }.toMutableList()
            val keptPlayerIds = keptStats.map { it.playerId }.toSet()
            val playersMap = getPlayersByTournamentOnce(match.tournamentId).associateBy { it.id }
            for (pid in selectedIds) {
                if (pid !in keptPlayerIds) {
                    val p = playersMap[pid] ?: continue
                    keptStats.add(
                        PlayerMatchStatEntity(
                            tournamentId = match.tournamentId,
                            matchId = matchId,
                            teamId = p.teamId,
                            playerId = p.id,
                            playerName = p.name,
                            innings = if (p.teamId == firstBatId) 1 else 2,
                            didBat = false,
                            didBowl = false
                        )
                    )
                }
            }
            deletePlayerMatchStatsForMatch(matchId)
            if (keptStats.isNotEmpty()) {
                insertPlayerMatchStats(keptStats.map { it.copy(id = 0, matchId = matchId, tournamentId = match.tournamentId) })
            }
            rebuildTournamentPlayerStats(match.tournamentId)
        }
    }

    @Transaction
    suspend fun recalculateAllTournaments(): Int {
        val tournaments = getAllTournamentsOnce()
        for (t in tournaments) {
            val matches = getMatchesByTournamentOnce(t.id)
            for (m in matches) {
                if (m.status == MatchStatus.COMPLETED) {
                    val stageAllOut = CricketStatsEngine.effectiveStageRules(t, m.stage).allOutWickets
                    val firstBat = if (m.battingFirstTeamId == m.teamBId) m.teamBId else m.teamAId
                    val (winnerId, summary) = CricketStatsEngine.resolveMatchOutcome(
                        teamAId = m.teamAId,
                        teamAName = m.teamAName,
                        teamARuns = m.teamARuns,
                        teamAWickets = m.teamAWickets,
                        teamBId = m.teamBId,
                        teamBName = m.teamBName,
                        teamBRuns = m.teamBRuns,
                        teamBWickets = m.teamBWickets,
                        battingFirstTeamId = firstBat,
                        allOutWickets = stageAllOut,
                        isAbandoned = false,
                        tieRule = t.tieRule,
                        superOverWinnerTeamId = m.winnerTeamId
                    )
                    if (m.winnerTeamId != winnerId || m.resultSummary != summary || m.battingFirstTeamId != firstBat) {
                        updateMatch(
                            m.copy(
                                battingFirstTeamId = firstBat,
                                winnerTeamId = winnerId,
                                resultSummary = summary,
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                    }
                }
            }
            rebuildTournamentPlayerStats(t.id)
            recalculateTournamentStandings(t.id)
        }
        return tournaments.size
    }

    @Transaction
    suspend fun replaceTournamentBundle(
        tournament: TournamentEntity,
        teams: List<TeamEntity>,
        players: List<PlayerEntity>,
        matches: List<MatchEntity>,
        balls: List<BallEventEntity>,
        members: List<TournamentMemberEntity>,
        logs: List<AuditLogEntity>,
        playerMatchStats: List<PlayerMatchStatEntity> = emptyList()
    ): Long {
        val newTId = insertTournament(tournament.copy(id = 0))
        val teamIdMap = mutableMapOf<Long, Long>()
        for (t in teams) {
            val insertedTeamId = insertTeam(t.copy(id = 0, tournamentId = newTId))
            teamIdMap[t.id] = insertedTeamId
        }
        val playerIdMap = mutableMapOf<Long, Long>()
        for (p in players) {
            val mappedTeamId = teamIdMap[p.teamId] ?: continue
            val insertedPlayerId = insertPlayer(p.copy(id = 0, tournamentId = newTId, teamId = mappedTeamId))
            playerIdMap[p.id] = insertedPlayerId
        }
        val matchIdMap = mutableMapOf<Long, Long>()
        for (m in matches) {
            val mappedA = teamIdMap[m.teamAId] ?: m.teamAId
            val mappedB = teamIdMap[m.teamBId] ?: m.teamBId
            val mappedAPlaying = CricketStatsEngine.formatPlayingIds(
                CricketStatsEngine.parsePlayingIds(m.teamAPlayingIds).mapNotNull { playerIdMap[it] }
            )
            val mappedBPlaying = CricketStatsEngine.formatPlayingIds(
                CricketStatsEngine.parsePlayingIds(m.teamBPlayingIds).mapNotNull { playerIdMap[it] }
            )
            val insertedMatchId = insertMatch(
                m.copy(
                    id = 0,
                    tournamentId = newTId,
                    teamAId = mappedA,
                    teamBId = mappedB,
                    battingFirstTeamId = teamIdMap[m.battingFirstTeamId] ?: mappedA,
                    activeStrikerId = playerIdMap[m.activeStrikerId] ?: 0L,
                    activeNonStrikerId = playerIdMap[m.activeNonStrikerId] ?: 0L,
                    activeBowlerId = playerIdMap[m.activeBowlerId] ?: 0L,
                    teamAPlayingIds = mappedAPlaying,
                    teamBPlayingIds = mappedBPlaying,
                    winnerTeamId = teamIdMap[m.winnerTeamId] ?: 0L,
                    playerOfMatchId = playerIdMap[m.playerOfMatchId] ?: 0L
                )
            )
            matchIdMap[m.id] = insertedMatchId
        }
        for (b in balls) {
            val mappedMatchId = matchIdMap[b.matchId] ?: continue
            insertBallEvent(
                b.copy(
                    id = 0,
                    tournamentId = newTId,
                    matchId = mappedMatchId,
                    strikerId = playerIdMap[b.strikerId] ?: 0L,
                    nonStrikerId = playerIdMap[b.nonStrikerId] ?: 0L,
                    bowlerId = playerIdMap[b.bowlerId] ?: 0L,
                    dismissedPlayerId = playerIdMap[b.dismissedPlayerId] ?: 0L
                )
            )
        }
        val mappedStats = playerMatchStats.mapNotNull { st ->
            val mappedMatchId = matchIdMap[st.matchId] ?: return@mapNotNull null
            val mappedTeamId = teamIdMap[st.teamId] ?: return@mapNotNull null
            val mappedPlayerId = playerIdMap[st.playerId] ?: return@mapNotNull null
            st.copy(
                id = 0,
                tournamentId = newTId,
                matchId = mappedMatchId,
                teamId = mappedTeamId,
                playerId = mappedPlayerId
            )
        }
        if (mappedStats.isNotEmpty()) {
            insertPlayerMatchStats(mappedStats)
        }
        for (mem in members) {
            insertMember(mem.copy(id = 0, tournamentId = newTId))
        }
        for (log in logs) {
            insertAuditLog(log.copy(id = 0, tournamentId = newTId))
        }
        return newTId
    }

    @Transaction
    suspend fun replaceTournamentBundleInPlace(
        existingTournamentId: Long?,
        tournament: TournamentEntity,
        teams: List<TeamEntity>,
        players: List<PlayerEntity>,
        matches: List<MatchEntity>,
        balls: List<BallEventEntity>,
        members: List<TournamentMemberEntity>,
        logs: List<AuditLogEntity>,
        playerMatchStats: List<PlayerMatchStatEntity> = emptyList()
    ): Long {
        if (existingTournamentId != null) {
            deleteTournament(existingTournamentId)
        }
        return replaceTournamentBundle(
            tournament = tournament,
            teams = teams,
            players = players,
            matches = matches,
            balls = balls,
            members = members,
            logs = logs,
            playerMatchStats = playerMatchStats
        )
    }
}
