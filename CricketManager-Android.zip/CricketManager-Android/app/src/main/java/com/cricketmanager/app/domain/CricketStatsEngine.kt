package com.cricketmanager.app.domain

import com.cricketmanager.app.data.local.BallEventEntity
import com.cricketmanager.app.data.local.ExtraType
import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.MatchStage
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PitchType
import com.cricketmanager.app.data.local.PlayoffType
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerMatchStatEntity
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.local.TieRule
import com.cricketmanager.app.data.local.TournamentEntity
import com.cricketmanager.app.data.local.TournamentFormat
import com.cricketmanager.app.data.local.WicketType
import java.util.Locale
import kotlin.math.abs

data class MottBreakdown(
    val battingScore: Double = 0.0,
    val bowlingScore: Double = 0.0,
    val inningsCounted: Int = 0,
    val finalBoostedMatches: Int = 0
) {
    val totalScore: Double get() = (battingScore + bowlingScore).coerceAtLeast(0.0)
}

data class StageRules(
    val playersPerSide: Int,
    val squadSize: Int,
    val overs: Int,
    val allOutWickets: Int,
    val maxOversPerBowler: Int
)

data class TournamentPreset(
    val id: String,
    val labelBn: String,
    val labelEn: String,
    val oversPerMatch: Int,
    val playersPerSide: Int,
    val squadSize: Int,
    val allOutWickets: Int,
    val maxOversPerBowler: Int,
    val pitchType: PitchType,
    val rulesSummary: String
)

object CricketStatsEngine {

    const val DEFAULT_ALL_OUT_WICKETS = 8

    val TOURNAMENT_PRESETS = listOf(
        TournamentPreset(
            id = "T20_STANDARD",
            labelBn = "২০ ওভার সাধারণ",
            labelEn = "20 Overs Standard",
            oversPerMatch = 20,
            playersPerSide = 11,
            squadSize = 15,
            allOutWickets = 10,
            maxOversPerBowler = 4,
            pitchType = PitchType.FULL_PITCH,
            rulesSummary = "Standard 20-over cricket · 11 players · Max 4 overs/bowler · Wide/NB = 1 run."
        ),
        TournamentPreset(
            id = "T10_STANDARD",
            labelBn = "১০ ওভার",
            labelEn = "10 Overs",
            oversPerMatch = 10,
            playersPerSide = 11,
            squadSize = 15,
            allOutWickets = 10,
            maxOversPerBowler = 2,
            pitchType = PitchType.FULL_PITCH,
            rulesSummary = "10 overs fast format · 11 players · Max 2 overs/bowler · Wide/NB = 1 run."
        ),
        TournamentPreset(
            id = "EIGHT_OVER_SHORT_PITCH",
            labelBn = "৮ ওভার শর্ট পিচ, ৮ জন",
            labelEn = "8 Overs Short Pitch, 8 Players",
            oversPerMatch = 8,
            playersPerSide = 8,
            squadSize = 12,
            allOutWickets = 7,
            maxOversPerBowler = 2,
            pitchType = PitchType.SHORT_PITCH,
            rulesSummary = "8 overs short pitch · 8 players/side · All-out 7 wickets · Max 2 overs/bowler."
        )
    )

    fun formatRulesSummary(
        oversPerMatch: Int,
        pitchType: PitchType,
        playersPerSide: Int,
        allOutWickets: Int,
        maxOversPerBowler: Int
    ): String {
        val pitchLabel = if (pitchType == PitchType.SHORT_PITCH) "short pitch" else "full pitch"
        return "$oversPerMatch overs $pitchLabel · $playersPerSide players/side · All-out $allOutWickets wickets · Max $maxOversPerBowler overs/bowler."
    }

    fun formatRulesSummary(tournament: TournamentEntity): String {
        return formatRulesSummary(
            oversPerMatch = tournament.oversPerMatch,
            pitchType = tournament.pitchType,
            playersPerSide = tournament.playersPerSide,
            allOutWickets = tournament.allOutWickets,
            maxOversPerBowler = tournament.maxOversPerBowler
        )
    }

    fun sortMatchesChronologically(matches: List<MatchEntity>): List<MatchEntity> {
        return matches.sortedWith(
            compareBy<MatchEntity>({ it.scheduledDate }, { it.scheduledTime }, { it.matchNumber }, { it.id })
        )
    }

    fun renumberLeagueMatchesByDate(matches: List<MatchEntity>): List<MatchEntity> {
        val leagueSorted = matches
            .filter { it.stage == MatchStage.LEAGUE || it.stage == MatchStage.GROUP }
            .sortedWith(compareBy<MatchEntity>({ it.scheduledDate }, { it.scheduledTime }, { it.id }))
            .mapIndexed { idx, m -> m.copy(matchNumber = idx + 1) }
        val nonLeagueSorted = matches
            .filter { it.stage != MatchStage.LEAGUE && it.stage != MatchStage.GROUP }
            .sortedWith(compareBy<MatchEntity>({ it.scheduledDate }, { it.scheduledTime }, { it.id }))
            .mapIndexed { idx, m -> m.copy(matchNumber = leagueSorted.size + idx + 1) }
        return sortMatchesChronologically(leagueSorted + nonLeagueSorted)
    }

    fun effectiveStageRules(tournament: TournamentEntity, stage: MatchStage): StageRules {
        val rawPlayers: Int
        val rawSquad: Int
        val rawOvers: Int
        when (stage) {
            MatchStage.LEAGUE, MatchStage.GROUP -> {
                rawPlayers = if (tournament.leaguePlayersPerSide > 0) tournament.leaguePlayersPerSide else tournament.playersPerSide
                rawSquad = if (tournament.leagueSquadSize > 0) tournament.leagueSquadSize else tournament.squadSize
                rawOvers = if (tournament.leagueOvers > 0) tournament.leagueOvers else tournament.oversPerMatch
            }
            MatchStage.FINAL -> {
                rawPlayers = if (tournament.finalPlayersPerSide > 0) tournament.finalPlayersPerSide else tournament.playersPerSide
                rawSquad = if (tournament.finalSquadSize > 0) tournament.finalSquadSize else tournament.squadSize
                rawOvers = if (tournament.finalOvers > 0) tournament.finalOvers else tournament.oversPerMatch
            }
            MatchStage.KNOCKOUT, MatchStage.SEMI_FINAL, MatchStage.QUALIFIER_1, MatchStage.ELIMINATOR, MatchStage.QUALIFIER_2 -> {
                rawPlayers = if (tournament.playoffPlayersPerSide > 0) tournament.playoffPlayersPerSide else tournament.playersPerSide
                rawSquad = if (tournament.playoffSquadSize > 0) tournament.playoffSquadSize else tournament.squadSize
                rawOvers = if (tournament.playoffOvers > 0) tournament.playoffOvers else tournament.oversPerMatch
            }
        }
        val players = rawPlayers.coerceIn(2, 15)
        val squad = rawSquad.coerceIn(players, 30)
        val overs = rawOvers.coerceIn(1, 50)
        val allOut = if (players != tournament.playersPerSide) {
            (players - 1).coerceAtLeast(1)
        } else {
            tournament.allOutWickets.coerceIn(1, players)
        }
        val baseMaxBowl = tournament.maxOversPerBowler.coerceAtLeast(1)
        val maxBowl = if (overs == tournament.oversPerMatch) {
            baseMaxBowl.coerceIn(1, overs)
        } else {
            ((overs + 4) / 5).coerceIn(1, overs)
        }
        return StageRules(
            playersPerSide = players,
            squadSize = squad,
            overs = overs,
            allOutWickets = allOut,
            maxOversPerBowler = maxBowl
        )
    }

    fun effectiveAllOutForMatch(match: MatchEntity, tournament: TournamentEntity?): Int {
        return when {
            match.allOutWicketsSnapshot > 0 -> match.allOutWicketsSnapshot
            tournament != null -> effectiveStageRules(tournament, match.stage).allOutWickets
            else -> DEFAULT_ALL_OUT_WICKETS
        }.coerceAtLeast(1)
    }

    fun effectivePlayersPerSideForMatch(match: MatchEntity, tournament: TournamentEntity?): Int {
        return when {
            match.playersPerSideSnapshot > 0 -> match.playersPerSideSnapshot
            tournament != null -> effectiveStageRules(tournament, match.stage).playersPerSide
            else -> 11
        }.coerceAtLeast(2)
    }

    fun parsePlayingIds(csv: String): List<Long> {
        if (csv.isBlank()) return emptyList()
        return csv.split(",").mapNotNull { it.trim().toLongOrNull() }.filter { it > 0L }.distinct()
    }

    fun formatPlayingIds(ids: Collection<Long>): String {
        return ids.filter { it > 0L }.distinct().joinToString(",")
    }

    fun validatePlayingSelection(selectedIds: Collection<Long>, limitPlayers: Int): String? {
        val required = limitPlayers.coerceAtLeast(1)
        val count = selectedIds.filter { it > 0L }.distinct().size
        return when {
            count < required -> "এই ম্যাচের জন্য ঠিক $required জন খেলোয়াড় বাছাই করতে হবে (এখন বাছাই: $count)"
            count > required -> "এই পর্বের ঠিক $required জন খেলোয়াড়ের বেশি বাছা যাবে না (বাছাই: $count)"
            else -> null
        }
    }

    fun isLegalDelivery(extraType: ExtraType): Boolean {
        return extraType == ExtraType.NONE || extraType == ExtraType.BYE || extraType == ExtraType.LEG_BYE
    }

    fun formatOvers(legalBalls: Int): String {
        val safe = legalBalls.coerceAtLeast(0)
        return "${safe / 6}.${safe % 6}"
    }

    fun isValidOversInput(oversInput: String): Boolean {
        val trimmed = oversInput.trim()
        if (trimmed.isEmpty()) return true
        return Regex("^\\d+(\\.[0-5])?$").matches(trimmed)
    }

    fun parseOversToBalls(oversInput: String): Int {
        val trimmed = oversInput.trim()
        if (trimmed.isEmpty()) return 0
        val parts = trimmed.split(".")
        val completedOvers = parts[0].toIntOrNull()?.coerceAtLeast(0) ?: 0
        val extraBalls = if (parts.size > 1) {
            parts[1].take(1).toIntOrNull()?.coerceIn(0, 5) ?: 0
        } else 0
        return completedOvers * 6 + extraBalls
    }

    fun effectiveInningsBalls(
        wickets: Int,
        balls: Int,
        maxOvers: Int,
        allOutWickets: Int = DEFAULT_ALL_OUT_WICKETS
    ): Int {
        val maxBalls = maxOvers.coerceAtLeast(1) * 6
        return if (wickets >= allOutWickets || balls <= 0) maxBalls else balls
    }

    fun addDaysToYmd(startDateLabel: String, daysToAdd: Int): String {
        val parts = startDateLabel.trim().split("-")
        var year = parts.getOrNull(0)?.toIntOrNull() ?: 2026
        var month = parts.getOrNull(1)?.toIntOrNull() ?: 5
        var day = parts.getOrNull(2)?.toIntOrNull() ?: 1
        if (year !in 1970..2100 || month !in 1..12 || day !in 1..31) {
            year = 2026
            month = 5
            day = 1
        }
        fun isLeap(y: Int): Boolean = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)
        fun daysInMonth(y: Int, m: Int): Int = when (m) {
            1, 3, 5, 7, 8, 10, 12 -> 31
            4, 6, 9, 11 -> 30
            2 -> if (isLeap(y)) 29 else 28
            else -> 30
        }
        day = day.coerceIn(1, daysInMonth(year, month))
        var remaining = daysToAdd.coerceAtLeast(0)
        while (remaining > 0) {
            val dim = daysInMonth(year, month)
            if (day < dim) {
                day++
            } else {
                day = 1
                if (month < 12) {
                    month++
                } else {
                    month = 1
                    year++
                }
            }
            remaining--
        }
        return String.format(Locale.US, "%04d-%02d-%02d", year, month, day)
    }

    fun resolveMatchOutcome(
        teamAId: Long,
        teamAName: String,
        teamARuns: Int,
        teamAWickets: Int,
        teamBId: Long,
        teamBName: String,
        teamBRuns: Int,
        teamBWickets: Int,
        battingFirstTeamId: Long,
        allOutWickets: Int = DEFAULT_ALL_OUT_WICKETS,
        isAbandoned: Boolean = false,
        tieRule: TieRule = TieRule.SHARE_POINTS,
        superOverWinnerTeamId: Long = 0L
    ): Pair<Long, String> {
        if (isAbandoned) {
            return 0L to "ম্যাচ পরিত্যক্ত (পয়েন্ট ভাগ)"
        }
        if (teamARuns == teamBRuns) {
            if (tieRule == TieRule.SUPER_OVER) {
                if (superOverWinnerTeamId == teamAId) {
                    return teamAId to "$teamAName সুপার ওভারে জয়ী"
                }
                if (superOverWinnerTeamId == teamBId) {
                    return teamBId to "$teamBName সুপার ওভারে জয়ী"
                }
                return 0L to "ম্যাচ টাই ($teamARuns-$teamBRuns) · সুপার ওভার বাকি"
            }
            return 0L to "ম্যাচ টাই ($teamARuns-$teamBRuns)"
        }
        val firstBatIsB = battingFirstTeamId == teamBId
        return if (teamARuns > teamBRuns) {
            if (firstBatIsB) {
                val wicketsLeft = (allOutWickets - teamAWickets).coerceAtLeast(1)
                teamAId to "$teamAName জয়ী $wicketsLeft উইকেটে"
            } else {
                val margin = teamARuns - teamBRuns
                teamAId to "$teamAName জয়ী $margin রানে"
            }
        } else {
            if (firstBatIsB) {
                val margin = teamBRuns - teamARuns
                teamBId to "$teamBName জয়ী $margin রানে"
            } else {
                val wicketsLeft = (allOutWickets - teamBWickets).coerceAtLeast(1)
                teamBId to "$teamBName জয়ী $wicketsLeft উইকেটে"
            }
        }
    }

    fun computeTeamStandings(
        teams: List<TeamEntity>,
        matches: List<MatchEntity>,
        tournament: TournamentEntity,
        allOutWickets: Int = tournament.allOutWickets
    ): List<TeamEntity> {
        val safeAllOut = allOutWickets.coerceAtLeast(1)
        val statsMap = teams.associateBy({ it.id }) { team ->
            team.copy(
                played = 0,
                won = 0,
                lost = 0,
                tiedOrAbandoned = 0,
                points = 0,
                runsFor = 0,
                ballsFaced = 0,
                runsAgainst = 0,
                ballsBowled = 0
            )
        }.toMutableMap()

        for (match in matches) {
            if (match.stage != MatchStage.LEAGUE && match.stage != MatchStage.GROUP) continue
            if (match.status != MatchStatus.COMPLETED && match.status != MatchStatus.ABANDONED && match.status != MatchStatus.WALKOVER) continue
            val teamA = statsMap[match.teamAId] ?: continue
            val teamB = statsMap[match.teamBId] ?: continue

            if (match.status == MatchStatus.WALKOVER) {
                val aWon = match.winnerTeamId == match.teamAId
                val bWon = match.winnerTeamId == match.teamBId
                statsMap[teamA.id] = teamA.copy(
                    played = teamA.played + 1,
                    won = teamA.won + if (aWon) 1 else 0,
                    lost = teamA.lost + if (bWon) 1 else 0,
                    points = teamA.points + when {
                        aWon -> tournament.pointsWalkover
                        bWon -> tournament.pointsLoss
                        else -> tournament.pointsAbandoned
                    }
                )
                statsMap[teamB.id] = teamB.copy(
                    played = teamB.played + 1,
                    won = teamB.won + if (bWon) 1 else 0,
                    lost = teamB.lost + if (aWon) 1 else 0,
                    points = teamB.points + when {
                        bWon -> tournament.pointsWalkover
                        aWon -> tournament.pointsLoss
                        else -> tournament.pointsAbandoned
                    }
                )
                continue
            }

            if (match.status == MatchStatus.ABANDONED) {
                statsMap[teamA.id] = teamA.copy(
                    played = teamA.played + 1,
                    tiedOrAbandoned = teamA.tiedOrAbandoned + 1,
                    points = teamA.points + tournament.pointsAbandoned
                )
                statsMap[teamB.id] = teamB.copy(
                    played = teamB.played + 1,
                    tiedOrAbandoned = teamB.tiedOrAbandoned + 1,
                    points = teamB.points + tournament.pointsAbandoned
                )
                continue
            }

            val matchRules = effectiveStageRules(tournament, match.stage)
            val matchOvers = if (match.oversLimit > 0) match.oversLimit else matchRules.overs
            val matchAllOut = if (match.allOutWicketsSnapshot > 0) match.allOutWicketsSnapshot else safeAllOut
            val aBallsEff = effectiveInningsBalls(match.teamAWickets, match.teamABalls, matchOvers, matchAllOut)
            val bBallsEff = effectiveInningsBalls(match.teamBWickets, match.teamBBalls, matchOvers, matchAllOut)

            val tiedScores = match.teamARuns == match.teamBRuns
            val aWon = match.teamARuns > match.teamBRuns || (tiedScores && match.winnerTeamId == match.teamAId)
            val bWon = match.teamBRuns > match.teamARuns || (tiedScores && match.winnerTeamId == match.teamBId)
            val isSharedTie = tiedScores && match.winnerTeamId == 0L

            statsMap[teamA.id] = teamA.copy(
                played = teamA.played + 1,
                won = teamA.won + if (aWon) 1 else 0,
                lost = teamA.lost + if (bWon) 1 else 0,
                tiedOrAbandoned = teamA.tiedOrAbandoned + if (isSharedTie) 1 else 0,
                points = teamA.points + when {
                    aWon -> tournament.pointsWin
                    isSharedTie -> tournament.pointsTie
                    else -> tournament.pointsLoss
                },
                runsFor = teamA.runsFor + match.teamARuns,
                ballsFaced = teamA.ballsFaced + aBallsEff,
                runsAgainst = teamA.runsAgainst + match.teamBRuns,
                ballsBowled = teamA.ballsBowled + bBallsEff
            )

            statsMap[teamB.id] = teamB.copy(
                played = teamB.played + 1,
                won = teamB.won + if (bWon) 1 else 0,
                lost = teamB.lost + if (aWon) 1 else 0,
                tiedOrAbandoned = teamB.tiedOrAbandoned + if (isSharedTie) 1 else 0,
                points = teamB.points + when {
                    bWon -> tournament.pointsWin
                    isSharedTie -> tournament.pointsTie
                    else -> tournament.pointsLoss
                },
                runsFor = teamB.runsFor + match.teamBRuns,
                ballsFaced = teamB.ballsFaced + bBallsEff,
                runsAgainst = teamB.runsAgainst + match.teamARuns,
                ballsBowled = teamB.ballsBowled + aBallsEff
            )
        }
        return statsMap.values.toList()
    }

    fun buildMatchStatsFromBallEvents(
        match: MatchEntity,
        players: List<PlayerEntity>,
        balls: List<BallEventEntity>
    ): List<PlayerMatchStatEntity> {
        val dismissedIds = balls.filter { it.isWicket && it.dismissedPlayerId > 0L }
            .map { it.dismissedPlayerId }.toSet()
        val nonStrikerIds = balls.map { it.nonStrikerId }.toSet()
        val firstBatId = if (match.battingFirstTeamId == match.teamBId) match.teamBId else match.teamAId
        val selectedPlayingIds = (parsePlayingIds(match.teamAPlayingIds) + parsePlayingIds(match.teamBPlayingIds)).toSet()

        return players.mapNotNull { p ->
            val batEvents = balls.filter { it.strikerId == p.id }
            val bowlEvents = balls.filter { it.bowlerId == p.id }
            val batted = batEvents.isNotEmpty() || p.id in nonStrikerIds
            val bowled = bowlEvents.isNotEmpty()
            val inPlayingXi = p.id in selectedPlayingIds
            if (!batted && !bowled && !inPlayingXi) return@mapNotNull null
            val inningsNum = if (p.teamId == firstBatId) 1 else 2
            PlayerMatchStatEntity(
                tournamentId = match.tournamentId,
                matchId = match.id,
                teamId = p.teamId,
                playerId = p.id,
                playerName = p.name,
                innings = inningsNum,
                didBat = batted,
                runsScored = batEvents.sumOf { it.runsOffBat },
                ballsFaced = batEvents.count { it.extraType != ExtraType.WIDE },
                fours = batEvents.count { it.isBoundaryFour },
                sixes = batEvents.count { it.isBoundarySix },
                isNotOut = batted && p.id !in dismissedIds,
                didBowl = bowled,
                ballsBowled = bowlEvents.count { isLegalDelivery(it.extraType) },
                runsConceded = bowlEvents.sumOf {
                    if (it.extraType == ExtraType.BYE || it.extraType == ExtraType.LEG_BYE) 0
                    else it.runsOffBat + it.extraRuns
                },
                wicketsTaken = bowlEvents.count { it.isWicket && it.wicketType != WicketType.RUN_OUT }
            )
        }
    }

    fun aggregatePlayerCareerStats(
        players: List<PlayerEntity>,
        completedMatches: List<MatchEntity>,
        matchStatsByMatchId: Map<Long, List<PlayerMatchStatEntity>>,
        liveBallsByMatchId: Map<Long, List<BallEventEntity>> = emptyMap()
    ): List<PlayerEntity> {
        val acc = players.associateBy({ it.id }) { p ->
            p.copy(
                matchesPlayed = 0,
                inningsBatted = 0,
                runsScored = 0,
                ballsFaced = 0,
                fours = 0,
                sixes = 0,
                notOuts = 0,
                highestScore = 0,
                ballsBowled = 0,
                runsConceded = 0,
                wicketsTaken = 0,
                bestBowlingWickets = 0,
                bestBowlingRuns = 0,
                playerOfMatchCount = 0
            )
        }.toMutableMap()

        for (match in completedMatches) {
            if (match.playerOfMatchId > 0L) {
                acc[match.playerOfMatchId]?.let { pom ->
                    acc[pom.id] = pom.copy(playerOfMatchCount = pom.playerOfMatchCount + 1)
                }
            }
            val countedInMatch = mutableSetOf<Long>()
            val stats = matchStatsByMatchId[match.id].orEmpty()
            for (st in stats) {
                val p = acc[st.playerId] ?: continue
                countedInMatch.add(st.playerId)
                val batted = st.didBat || st.runsScored > 0 || st.ballsFaced > 0
                val bowled = st.didBowl || st.ballsBowled > 0 || st.runsConceded > 0 || st.wicketsTaken > 0
                var newBestW = p.bestBowlingWickets
                var newBestR = p.bestBowlingRuns
                if (bowled && st.wicketsTaken > 0) {
                    val betterBest = st.wicketsTaken > newBestW ||
                        (st.wicketsTaken == newBestW && (newBestW == 0 || st.runsConceded < newBestR))
                    if (betterBest) {
                        newBestW = st.wicketsTaken
                        newBestR = st.runsConceded
                    }
                }
                acc[p.id] = p.copy(
                    matchesPlayed = p.matchesPlayed + 1,
                    inningsBatted = p.inningsBatted + if (batted) 1 else 0,
                    runsScored = p.runsScored + st.runsScored,
                    ballsFaced = p.ballsFaced + st.ballsFaced,
                    fours = p.fours + st.fours,
                    sixes = p.sixes + st.sixes,
                    notOuts = p.notOuts + if (batted && st.isNotOut) 1 else 0,
                    highestScore = if (batted) maxOf(p.highestScore, st.runsScored) else p.highestScore,
                    ballsBowled = p.ballsBowled + st.ballsBowled,
                    runsConceded = p.runsConceded + st.runsConceded,
                    wicketsTaken = p.wicketsTaken + st.wicketsTaken,
                    bestBowlingWickets = newBestW,
                    bestBowlingRuns = newBestR
                )
            }
            val playingIds = (parsePlayingIds(match.teamAPlayingIds) + parsePlayingIds(match.teamBPlayingIds)).distinct()
            for (pid in playingIds) {
                if (pid !in countedInMatch) {
                    acc[pid]?.let { p ->
                        acc[pid] = p.copy(matchesPlayed = p.matchesPlayed + 1)
                    }
                }
            }
        }

        for ((_, balls) in liveBallsByMatchId) {
            for (b in balls) {
                if (b.strikerId > 0L) {
                    acc[b.strikerId]?.let { batter ->
                        val batterBalls = if (b.extraType != ExtraType.WIDE) 1 else 0
                        acc[batter.id] = batter.copy(
                            runsScored = batter.runsScored + b.runsOffBat,
                            ballsFaced = batter.ballsFaced + batterBalls,
                            fours = batter.fours + if (b.runsOffBat == 4) 1 else 0,
                            sixes = batter.sixes + if (b.runsOffBat == 6) 1 else 0
                        )
                    }
                }
                if (b.bowlerId > 0L) {
                    acc[b.bowlerId]?.let { bowler ->
                        val bowlerConceded = when (b.extraType) {
                            ExtraType.BYE, ExtraType.LEG_BYE -> 0
                            else -> b.runsOffBat + b.extraRuns
                        }
                        val countsAsWicket = b.isWicket && b.wicketType != WicketType.RUN_OUT
                        acc[bowler.id] = bowler.copy(
                            ballsBowled = bowler.ballsBowled + if (isLegalDelivery(b.extraType)) 1 else 0,
                            runsConceded = bowler.runsConceded + bowlerConceded,
                            wicketsTaken = bowler.wicketsTaken + if (countsAsWicket) 1 else 0
                        )
                    }
                }
            }
        }

        return acc.values.toList()
    }

    private fun safeFinite(value: Double): Double = if (value.isFinite()) value else 0.0

    private fun safeDivide(numerator: Double, denominator: Double): Double {
        if (!numerator.isFinite() || !denominator.isFinite() || denominator <= 0.0) return 0.0
        return safeFinite(numerator / denominator)
    }

    fun calculateNetRunRate(
        runsFor: Int,
        ballsFaced: Int,
        runsAgainst: Int,
        ballsBowled: Int
    ): Double {
        val oversFor = if (ballsFaced > 0) ballsFaced / 6.0 else 0.0
        val oversAgainst = if (ballsBowled > 0) ballsBowled / 6.0 else 0.0
        val runRateFor = safeDivide(runsFor.toDouble(), oversFor)
        val runRateAgainst = safeDivide(runsAgainst.toDouble(), oversAgainst)
        return safeFinite(runRateFor - runRateAgainst)
    }

    fun formatNrr(nrr: Double): String {
        val clean = safeFinite(nrr)
        val sign = if (clean > 0.0005) "+" else if (clean < -0.0005) "-" else ""
        return String.format(Locale.US, "%s%.3f", sign, abs(clean))
    }

    fun calculateStrikeRate(runs: Int, balls: Int): Double {
        return safeDivide(runs * 100.0, balls.toDouble())
    }

    fun calculateBattingAverage(runs: Int, innings: Int, notOuts: Int): Double {
        val dismissals = (innings - notOuts).coerceAtLeast(0)
        return if (dismissals > 0) safeDivide(runs.toDouble(), dismissals.toDouble()) else runs.toDouble().coerceAtLeast(0.0)
    }

    fun calculateEconomyRate(runsConceded: Int, ballsBowled: Int): Double {
        if (ballsBowled <= 0) return 0.0
        return safeDivide(runsConceded.toDouble(), ballsBowled / 6.0)
    }

    fun calculateBowlingAverage(runsConceded: Int, wickets: Int): Double {
        return safeDivide(runsConceded.toDouble(), wickets.toDouble())
    }

    fun calculateRequiredRunRate(target: Int, currentRuns: Int, ballsBowled: Int, totalOvers: Int): Double {
        val runsNeeded = (target - currentRuns).coerceAtLeast(0)
        val ballsLeft = (totalOvers.coerceAtLeast(1) * 6 - ballsBowled).coerceAtLeast(1)
        return safeDivide(runsNeeded.toDouble(), ballsLeft / 6.0)
    }

    fun calculateCurrentRunRate(runs: Int, ballsBowled: Int): Double {
        if (ballsBowled <= 0) return 0.0
        return safeDivide(runs.toDouble(), ballsBowled / 6.0)
    }

    fun calculateMatchStatsImpact(
        stats: List<PlayerMatchStatEntity>,
        tournament: TournamentEntity? = null
    ): Map<Long, MottBreakdown> {
        if (stats.isEmpty()) return emptyMap()
        val batWeight = (tournament?.mottBattingWeight ?: 1.0).takeIf { it.isFinite() && it >= 0.0 } ?: 1.0
        val bowlWeight = (tournament?.mottBowlingWeight ?: 1.0).takeIf { it.isFinite() && it >= 0.0 } ?: 1.0
        val wktShare = (tournament?.mottBowlingWicketShare ?: 0.6).takeIf { it.isFinite() && it >= 0.0 } ?: 0.6
        val econShare = (tournament?.mottBowlingEconomyShare ?: 0.4).takeIf { it.isFinite() && it >= 0.0 } ?: 0.4
        val fullWktShare = (wktShare + econShare).takeIf { it.isFinite() && it > 0.0 } ?: 1.0

        val batters = stats.filter { it.didBat || it.runsScored > 0 || it.ballsFaced > 0 }
        val avgRuns = if (batters.isNotEmpty()) {
            batters.map { it.runsScored.coerceAtLeast(0) }.average().takeIf { it.isFinite() && it > 0.0 } ?: 1.0
        } else 1.0

        val bowlers = stats.filter { it.didBowl || it.ballsBowled > 0 || it.wicketsTaken > 0 }
        val avgWkts = if (bowlers.isNotEmpty()) {
            bowlers.map { it.wicketsTaken.coerceAtLeast(0) }.average().takeIf { it.isFinite() && it > 0.0 } ?: 0.0
        } else 0.0
        val bowlersWithEcon = bowlers.filter { it.ballsBowled > 0 }
        val totalBalls = bowlersWithEcon.sumOf { it.ballsBowled }
        val totalConc = bowlersWithEcon.sumOf { it.runsConceded.coerceAtLeast(0) }
        val avgEcon = if (totalBalls > 0) calculateEconomyRate(totalConc, totalBalls) else 0.0

        return stats.associate { st ->
            val didBat = st.didBat || st.runsScored > 0 || st.ballsFaced > 0
            val didBowl = st.didBowl || st.ballsBowled > 0 || st.wicketsTaken > 0
            val batPart = if (didBat) safeFinite(safeDivide(st.runsScored.coerceAtLeast(0).toDouble(), avgRuns) * batWeight) else 0.0
            val bowlPart = if (didBowl) {
                val hasEconData = st.ballsBowled > 0 && avgEcon > 0.0
                val activeWktShare = if (hasEconData) wktShare else fullWktShare
                val wPart = if (avgWkts > 0.0) {
                    safeDivide(st.wicketsTaken.coerceAtLeast(0).toDouble(), avgWkts) * activeWktShare
                } else 0.0
                val ePart = if (hasEconData) {
                    val econ = calculateEconomyRate(st.runsConceded.coerceAtLeast(0), st.ballsBowled)
                    val ratio = if (econ <= 0.0) 3.0 else safeDivide(avgEcon, econ).coerceAtMost(3.0)
                    ratio * econShare
                } else 0.0
                safeFinite((wPart + ePart) * bowlWeight)
            } else 0.0
            st.playerId to MottBreakdown(
                battingScore = batPart,
                bowlingScore = bowlPart,
                inningsCounted = if (didBat) 1 else 0
            )
        }
    }

    fun pickAutoManOfTheMatch(
        stats: List<PlayerMatchStatEntity>,
        winningTeamId: Long,
        tournament: TournamentEntity? = null
    ): Pair<PlayerMatchStatEntity, Double>? {
        val impacts = calculateMatchStatsImpact(stats, tournament)
        return stats.map { st ->
            st to (impacts[st.playerId]?.totalScore ?: 0.0)
        }.maxWithOrNull(
            compareBy<Pair<PlayerMatchStatEntity, Double>> { it.second }
                .thenBy { if (winningTeamId > 0L && it.first.teamId == winningTeamId) 1 else 0 }
                .thenBy { it.first.runsScored + it.first.wicketsTaken * 20 }
        )
    }

    fun calculateBallEventsImpactMap(
        players: List<PlayerEntity>,
        balls: List<BallEventEntity>,
        winningTeamId: Long,
        tournament: TournamentEntity? = null
    ): List<Pair<PlayerEntity, MottBreakdown>> {
        val dismissedIds = balls.filter { it.isWicket && it.dismissedPlayerId > 0L }
            .map { it.dismissedPlayerId }.toSet()
        val nonStrikerIds = balls.map { it.nonStrikerId }.toSet()

        val tempStats = players.map { p ->
            val batBalls = balls.filter { it.strikerId == p.id }
            val bowlBalls = balls.filter { it.bowlerId == p.id }
            val didBat = batBalls.isNotEmpty() || p.id in nonStrikerIds
            val didBowl = bowlBalls.isNotEmpty()
            PlayerMatchStatEntity(
                tournamentId = p.tournamentId,
                matchId = 0L,
                teamId = p.teamId,
                playerId = p.id,
                playerName = p.name,
                innings = 1,
                didBat = didBat,
                runsScored = batBalls.sumOf { it.runsOffBat },
                ballsFaced = batBalls.count { it.extraType != ExtraType.WIDE },
                fours = batBalls.count { it.isBoundaryFour },
                sixes = batBalls.count { it.isBoundarySix },
                isNotOut = didBat && p.id !in dismissedIds,
                didBowl = didBowl,
                ballsBowled = bowlBalls.count { isLegalDelivery(it.extraType) },
                runsConceded = bowlBalls.sumOf {
                    if (it.extraType == ExtraType.BYE || it.extraType == ExtraType.LEG_BYE) 0
                    else it.runsOffBat + it.extraRuns
                },
                wicketsTaken = bowlBalls.count { it.isWicket && it.wicketType != WicketType.RUN_OUT }
            )
        }
        val impactMap = calculateMatchStatsImpact(tempStats, tournament)
        return players.map { p ->
            p to (impactMap[p.id] ?: MottBreakdown())
        }.sortedWith(
            compareByDescending<Pair<PlayerEntity, MottBreakdown>> { it.second.totalScore }
                .thenByDescending { if (winningTeamId > 0L && it.first.teamId == winningTeamId) 1 else 0 }
                .thenByDescending { it.first.runsScored + it.first.wicketsTaken * 20 }
        )
    }

    fun calculateTournamentMottBreakdownMap(
        players: List<PlayerEntity>,
        allMatchStats: List<PlayerMatchStatEntity>,
        allMatches: List<MatchEntity>,
        tournament: TournamentEntity? = null
    ): Map<Long, MottBreakdown> {
        if (players.isEmpty()) return emptyMap()
        val batWeight = (tournament?.mottBattingWeight ?: 1.0).takeIf { it.isFinite() && it >= 0.0 } ?: 1.0
        val bowlWeight = (tournament?.mottBowlingWeight ?: 1.0).takeIf { it.isFinite() && it >= 0.0 } ?: 1.0
        val wktShare = (tournament?.mottBowlingWicketShare ?: 0.6).takeIf { it.isFinite() && it >= 0.0 } ?: 0.6
        val econShare = (tournament?.mottBowlingEconomyShare ?: 0.4).takeIf { it.isFinite() && it >= 0.0 } ?: 0.4
        val fullWktShare = (wktShare + econShare).takeIf { it.isFinite() && it > 0.0 } ?: 1.0
        val finalMultiplier = (tournament?.mottFinalMultiplier ?: 1.5).takeIf { it.isFinite() && it >= 0.5 } ?: 1.5

        val completedMatchMap = allMatches.filter { it.status == MatchStatus.COMPLETED }.associateBy { it.id }
        val completedIds = completedMatchMap.keys
        val validStats = allMatchStats.filter { it.matchId in completedIds || completedIds.isEmpty() }

        if (validStats.isNotEmpty()) {
            val batters = validStats.filter { it.didBat || it.runsScored > 0 || it.ballsFaced > 0 }
            val avgBatterRuns = if (batters.isNotEmpty()) {
                batters.map { it.runsScored.coerceAtLeast(0) }.average().takeIf { it.isFinite() && it > 0.0 } ?: 1.0
            } else 1.0

            val bowlers = validStats.filter { it.didBowl || it.ballsBowled > 0 || it.wicketsTaken > 0 }
            val avgBowlerWickets = if (bowlers.isNotEmpty()) {
                bowlers.map { it.wicketsTaken.coerceAtLeast(0) }.average().takeIf { it.isFinite() && it > 0.0 } ?: 0.0
            } else 0.0
            val bowlersWithEcon = bowlers.filter { it.ballsBowled > 0 }
            val totalBalls = bowlersWithEcon.sumOf { it.ballsBowled }
            val totalConceded = bowlersWithEcon.sumOf { it.runsConceded.coerceAtLeast(0) }
            val avgTournamentEcon = if (totalBalls > 0) calculateEconomyRate(totalConceded, totalBalls) else 0.0

            val statsByPlayer = validStats.groupBy { it.playerId }
            return players.associate { p ->
                val pStats = statsByPlayer[p.id].orEmpty()
                var batSum = 0.0
                var bowlSum = 0.0
                var batInnings = 0
                var finalMatches = 0

                for (st in pStats) {
                    val matchObj = completedMatchMap[st.matchId]
                    val isFinal = matchObj?.stage == MatchStage.FINAL
                    val stageWeight = if (isFinal) finalMultiplier else 1.0
                    val didBat = st.didBat || st.runsScored > 0 || st.ballsFaced > 0
                    val didBowl = st.didBowl || st.ballsBowled > 0 || st.wicketsTaken > 0
                    if (isFinal && (didBat || didBowl)) finalMatches++

                    if (didBat) {
                        batInnings++
                        val normalizedBat = safeDivide(st.runsScored.coerceAtLeast(0).toDouble(), avgBatterRuns) * batWeight
                        batSum = safeFinite(batSum + safeFinite(normalizedBat * stageWeight))
                    }
                    if (didBowl) {
                        val hasEconData = st.ballsBowled > 0 && avgTournamentEcon > 0.0
                        val activeWktShare = if (hasEconData) wktShare else fullWktShare
                        val wktComponent = if (avgBowlerWickets > 0.0) {
                            safeDivide(st.wicketsTaken.coerceAtLeast(0).toDouble(), avgBowlerWickets) * activeWktShare
                        } else 0.0
                        val econComponent = if (hasEconData) {
                            val playerEcon = calculateEconomyRate(st.runsConceded.coerceAtLeast(0), st.ballsBowled)
                            val econRatio = if (playerEcon <= 0.0) 3.0 else safeDivide(avgTournamentEcon, playerEcon).coerceAtMost(3.0)
                            econRatio * econShare
                        } else 0.0
                        val normalizedBowl = (wktComponent + econComponent) * bowlWeight
                        bowlSum = safeFinite(bowlSum + safeFinite(normalizedBowl * stageWeight))
                    }
                }
                p.id to MottBreakdown(
                    battingScore = safeFinite(batSum),
                    bowlingScore = safeFinite(bowlSum),
                    inningsCounted = batInnings,
                    finalBoostedMatches = finalMatches
                )
            }
        }

        // Graceful fallback when only aggregate player career totals exist (no per-match records)
        val battersWithInns = players.filter { it.inningsBatted > 0 || it.runsScored > 0 }
        val avgRunsPerInns = if (battersWithInns.isNotEmpty()) {
            val totalRuns = battersWithInns.sumOf { it.runsScored.coerceAtLeast(0) }
            val totalInns = battersWithInns.sumOf { it.inningsBatted.coerceAtLeast(1) }
            safeDivide(totalRuns.toDouble(), totalInns.coerceAtLeast(1).toDouble()).coerceAtLeast(1.0)
        } else 1.0

        val bowlersWithMatches = players.filter { it.ballsBowled > 0 || it.wicketsTaken > 0 }
        val avgWktsPerBowler = if (bowlersWithMatches.isNotEmpty()) {
            bowlersWithMatches.map { it.wicketsTaken.coerceAtLeast(0) }.average().takeIf { it.isFinite() && it > 0.0 } ?: 0.0
        } else 0.0
        val fallbackEconBowlers = bowlersWithMatches.filter { it.ballsBowled > 0 }
        val totalBalls = fallbackEconBowlers.sumOf { it.ballsBowled }
        val totalConc = fallbackEconBowlers.sumOf { it.runsConceded.coerceAtLeast(0) }
        val avgEcon = if (totalBalls > 0) calculateEconomyRate(totalConc, totalBalls) else 0.0

        return players.associate { p ->
            val inns = if (p.runsScored > 0 || p.inningsBatted > 0) p.inningsBatted.coerceAtLeast(1) else 0
            val batScore = if (inns > 0) safeFinite(safeDivide(p.runsScored.coerceAtLeast(0).toDouble(), avgRunsPerInns) * batWeight) else 0.0
            val bowlScore = if (p.ballsBowled > 0 || p.wicketsTaken > 0) {
                val hasEconData = p.ballsBowled > 0 && avgEcon > 0.0
                val activeWktShare = if (hasEconData) wktShare else fullWktShare
                val wPart = if (avgWktsPerBowler > 0.0) {
                    safeDivide(p.wicketsTaken.coerceAtLeast(0).toDouble(), avgWktsPerBowler) * activeWktShare
                } else 0.0
                val ePart = if (hasEconData) {
                    val pEcon = calculateEconomyRate(p.runsConceded.coerceAtLeast(0), p.ballsBowled)
                    val ratio = if (pEcon <= 0.0) 3.0 else safeDivide(avgEcon, pEcon).coerceAtMost(3.0)
                    ratio * econShare
                } else 0.0
                safeFinite((wPart + ePart) * bowlWeight)
            } else 0.0
            p.id to MottBreakdown(
                battingScore = batScore,
                bowlingScore = bowlScore,
                inningsCounted = inns,
                finalBoostedMatches = 0
            )
        }
    }

    fun formatBallChip(
        runsOffBat: Int,
        extraRuns: Int,
        extraType: ExtraType,
        isWicket: Boolean
    ): String {
        if (isWicket) {
            return if (runsOffBat > 0) "${runsOffBat}+W" else "W"
        }
        return when (extraType) {
            ExtraType.NONE -> if (runsOffBat == 0) "•" else runsOffBat.toString()
            ExtraType.WIDE -> if (extraRuns > 1 || runsOffBat > 0) "${runsOffBat + extraRuns}Wd" else "Wd"
            ExtraType.NO_BALL -> if (runsOffBat > 0) "${runsOffBat}NB" else "NB"
            ExtraType.BYE -> "${runsOffBat + extraRuns}B"
            ExtraType.LEG_BYE -> "${runsOffBat + extraRuns}LB"
        }
    }

    private val SIX_TEAM_CIRCLE_ORDER = listOf(
        0 to 5, 1 to 4, 2 to 3,
        0 to 4, 5 to 3, 1 to 2,
        0 to 3, 4 to 2, 5 to 1,
        0 to 2, 3 to 1, 4 to 5,
        0 to 1, 2 to 5, 3 to 4
    )

    private fun arePairsDisjoint(a: Pair<Int, Int>, b: Pair<Int, Int>): Boolean {
        return a.first != b.first && a.first != b.second && a.second != b.first && a.second != b.second
    }

    private fun solveNonConsecutiveOrder(
        pairs: List<Pair<Int, Int>>,
        teamCount: Int,
        initialLastPair: Pair<Int, Int>?,
        initialLastPlayedDay: IntArray
    ): List<Pair<Int, Int>> {
        if (teamCount <= 4) {
            val out = mutableListOf<Pair<Int, Int>>()
            val rem = pairs.toMutableList()
            while (rem.isNotEmpty()) {
                val prev = out.lastOrNull() ?: initialLastPair
                val idx = if (prev != null) rem.indexOfFirst { arePairsDisjoint(prev, it) } else 0
                out.add(if (idx >= 0) rem.removeAt(idx) else rem.removeAt(0))
            }
            return out
        }

        val total = pairs.size
        val used = BooleanArray(total)
        val path = mutableListOf<Pair<Int, Int>>()
        val lastDay = initialLastPlayedDay.copyOf()
        var steps = 0
        val maxSteps = 50_000

        fun dfs(lastPair: Pair<Int, Int>?): Boolean {
            if (path.size == total) return true
            if (++steps > maxSteps) return false
            val day = path.size
            val cands = mutableListOf<Int>()
            for (idx in 0 until total) {
                if (!used[idx] && (lastPair == null || arePairsDisjoint(lastPair, pairs[idx]))) {
                    cands.add(idx)
                }
            }
            cands.sortWith(
                compareByDescending<Int> { idx ->
                    val p = pairs[idx]
                    minOf(day - lastDay[p.first], day - lastDay[p.second])
                }.thenByDescending { idx ->
                    val p = pairs[idx]
                    (day - lastDay[p.first]) + (day - lastDay[p.second])
                }
            )
            for (idx in cands) {
                val p = pairs[idx]
                used[idx] = true
                path.add(p)
                val prevA = lastDay[p.first]
                val prevB = lastDay[p.second]
                lastDay[p.first] = day
                lastDay[p.second] = day
                if (dfs(p)) return true
                lastDay[p.first] = prevA
                lastDay[p.second] = prevB
                path.removeAt(path.lastIndex)
                used[idx] = false
            }
            return false
        }

        if (dfs(initialLastPair)) return path

        val fallback = mutableListOf<Pair<Int, Int>>()
        val rem = pairs.toMutableList()
        while (rem.isNotEmpty()) {
            val prev = fallback.lastOrNull() ?: initialLastPair
            val idx = if (prev != null) rem.indexOfFirst { arePairsDisjoint(prev, it) } else 0
            fallback.add(if (idx >= 0) rem.removeAt(idx) else rem.removeAt(0))
        }
        return fallback
    }

    fun scheduleRoundRobinPairs(teamCount: Int, matchesPerPair: Int = 1): List<Pair<Int, Int>> {
        if (teamCount < 2) return emptyList()
        val repeatCount = matchesPerPair.coerceIn(1, 2)

        val allPairs = mutableListOf<Pair<Int, Int>>()
        for (i in 0 until teamCount) {
            for (j in i + 1 until teamCount) {
                allPairs.add(i to j)
            }
        }

        val singleRound = if (teamCount == 6) {
            SIX_TEAM_CIRCLE_ORDER
        } else {
            solveNonConsecutiveOrder(
                pairs = allPairs,
                teamCount = teamCount,
                initialLastPair = null,
                initialLastPlayedDay = IntArray(teamCount) { -100 }
            )
        }

        if (repeatCount == 1) return singleRound
        val secondPairs = singleRound.map { (a, b) -> b to a }
        val last1 = singleRound.last()
        if (teamCount == 6 && arePairsDisjoint(last1, secondPairs.first())) {
            return singleRound + secondPairs
        }
        val r2LastDay = IntArray(teamCount) { -100 }
        singleRound.forEachIndexed { idx, (a, b) ->
            val relDay = idx - singleRound.size
            r2LastDay[a] = relDay
            r2LastDay[b] = relDay
        }
        val secondRound = solveNonConsecutiveOrder(
            pairs = secondPairs,
            teamCount = teamCount,
            initialLastPair = last1,
            initialLastPlayedDay = r2LastDay
        )
        return singleRound + secondRound
    }

    fun hasConsecutiveDayMatch(matches: List<MatchEntity>): Boolean {
        val sorted = matches.sortedBy { it.matchNumber }
        for (idx in 1 until sorted.size) {
            val prev = sorted[idx - 1]
            val curr = sorted[idx]
            val sameDayOrAdjacent = prev.scheduledDate == curr.scheduledDate ||
                addDaysToYmd(prev.scheduledDate, 1) == curr.scheduledDate
            if (sameDayOrAdjacent) {
                val prevTeams = setOf(prev.teamAId, prev.teamBId)
                if (curr.teamAId in prevTeams || curr.teamBId in prevTeams) {
                    return true
                }
            }
        }
        return false
    }

    fun generateFixtures(
        tournamentId: Long,
        teams: List<TeamEntity>,
        format: TournamentFormat,
        oversPerMatch: Int,
        scoringMode: ScoringMode,
        venue: String,
        startDateLabel: String,
        startingMatchNumber: Int = 1,
        matchesPerPair: Int = 1,
        tournament: TournamentEntity? = null
    ): List<MatchEntity> {
        if (teams.size < 2) return emptyList()
        val fixtures = mutableListOf<MatchEntity>()
        var matchNo = startingMatchNumber
        var dayOffset = 0
        val baseDate = startDateLabel.ifBlank { "2026-05-01" }
        val repeatCount = matchesPerPair.coerceIn(1, 2)

        fun rulesForStage(stage: MatchStage): StageRules {
            return if (tournament != null) {
                effectiveStageRules(tournament, stage)
            } else {
                StageRules(
                    playersPerSide = 11,
                    squadSize = 15,
                    overs = oversPerMatch.coerceAtLeast(1),
                    allOutWickets = DEFAULT_ALL_OUT_WICKETS,
                    maxOversPerBowler = ((oversPerMatch.coerceAtLeast(1) + 4) / 5).coerceAtLeast(1)
                )
            }
        }

        when (format) {
            TournamentFormat.LEAGUE, TournamentFormat.ROUND_ROBIN -> {
                val rules = rulesForStage(MatchStage.LEAGUE)
                val pairSchedule = scheduleRoundRobinPairs(teams.size, repeatCount)
                for ((i, j) in pairSchedule) {
                    val a = teams[i]
                    val b = teams[j]
                    val matchDate = addDaysToYmd(baseDate, dayOffset++)
                    fixtures.add(
                        MatchEntity(
                            tournamentId = tournamentId,
                            matchNumber = matchNo++,
                            stage = MatchStage.LEAGUE,
                            groupName = "League",
                            teamAId = a.id,
                            teamBId = b.id,
                            teamAName = a.name,
                            teamBName = b.name,
                            venue = venue,
                            scheduledDate = matchDate,
                            scheduledTime = "15:00",
                            oversLimit = rules.overs,
                            playersPerSideSnapshot = rules.playersPerSide,
                            squadSizeSnapshot = rules.squadSize,
                            allOutWicketsSnapshot = rules.allOutWickets,
                            maxOversPerBowlerSnapshot = rules.maxOversPerBowler,
                            scoringMode = scoringMode,
                            status = MatchStatus.UPCOMING
                        )
                    )
                }
            }

            TournamentFormat.GROUP_KNOCKOUT -> {
                val rules = rulesForStage(MatchStage.GROUP)
                val grouped = teams.groupBy { it.groupName.ifBlank { "Group A" } }
                val groupQueues = grouped.map { (groupName, groupTeams) ->
                    val pairs = scheduleRoundRobinPairs(groupTeams.size, repeatCount)
                    groupName to pairs.map { (i, j) -> groupTeams[i] to groupTeams[j] }.toMutableList()
                }
                while (groupQueues.any { it.second.isNotEmpty() }) {
                    for ((group, queue) in groupQueues) {
                        val nextPair = queue.removeFirstOrNull() ?: continue
                        val (a, b) = nextPair
                        val matchDate = addDaysToYmd(baseDate, dayOffset++)
                        fixtures.add(
                            MatchEntity(
                                tournamentId = tournamentId,
                                matchNumber = matchNo++,
                                stage = MatchStage.GROUP,
                                groupName = group,
                                teamAId = a.id,
                                teamBId = b.id,
                                teamAName = a.name,
                                teamBName = b.name,
                                venue = venue,
                                scheduledDate = matchDate,
                                scheduledTime = "15:00",
                                oversLimit = rules.overs,
                                playersPerSideSnapshot = rules.playersPerSide,
                                squadSizeSnapshot = rules.squadSize,
                                allOutWicketsSnapshot = rules.allOutWickets,
                                maxOversPerBowlerSnapshot = rules.maxOversPerBowler,
                                scoringMode = scoringMode,
                                status = MatchStatus.UPCOMING
                            )
                        )
                    }
                }
            }

            TournamentFormat.KNOCKOUT -> {
                val rules = rulesForStage(MatchStage.KNOCKOUT)
                var idx = 0
                while (idx + 1 < teams.size) {
                    val a = teams[idx]
                    val b = teams[idx + 1]
                    val matchDate = addDaysToYmd(baseDate, dayOffset++)
                    fixtures.add(
                        MatchEntity(
                            tournamentId = tournamentId,
                            matchNumber = matchNo++,
                            stage = MatchStage.KNOCKOUT,
                            groupName = "Knockout",
                            teamAId = a.id,
                            teamBId = b.id,
                            teamAName = a.name,
                            teamBName = b.name,
                            venue = venue,
                            scheduledDate = matchDate,
                            scheduledTime = "15:00",
                            oversLimit = rules.overs,
                            playersPerSideSnapshot = rules.playersPerSide,
                            squadSizeSnapshot = rules.squadSize,
                            allOutWicketsSnapshot = rules.allOutWickets,
                            maxOversPerBowlerSnapshot = rules.maxOversPerBowler,
                            scoringMode = scoringMode,
                            status = MatchStatus.UPCOMING
                        )
                    )
                    idx += 2
                }
            }
        }
        return fixtures
    }

    private fun headToHeadCompare(teamAId: Long, teamBId: Long, matches: List<MatchEntity>): Int {
        var aWins = 0
        var bWins = 0
        for (m in matches) {
            if (m.stage != MatchStage.LEAGUE && m.stage != MatchStage.GROUP) continue
            if (m.status != MatchStatus.COMPLETED && m.status != MatchStatus.WALKOVER) continue
            val isPair = (m.teamAId == teamAId && m.teamBId == teamBId) || (m.teamAId == teamBId && m.teamBId == teamAId)
            if (!isPair) continue
            when (m.winnerTeamId) {
                teamAId -> aWins++
                teamBId -> bWins++
            }
        }
        return bWins.compareTo(aWins)
    }

    fun sortTeamsForPointsTable(
        teams: List<TeamEntity>,
        matches: List<MatchEntity> = emptyList(),
        tiebreakerOrder: String = "POINTS,WINS,NRR,H2H,NAME"
    ): List<TeamEntity> {
        val criteria = tiebreakerOrder.split(",").map { it.trim().uppercase() }.filter { it.isNotEmpty() }
            .ifEmpty { listOf("POINTS", "WINS", "NRR", "H2H", "NAME") }

        return teams.sortedWith { a, b ->
            for (token in criteria) {
                val cmp = when (token) {
                    "POINTS" -> b.points.compareTo(a.points)
                    "WINS" -> b.won.compareTo(a.won)
                    "NRR" -> {
                        val nrrA = calculateNetRunRate(a.runsFor, a.ballsFaced, a.runsAgainst, a.ballsBowled)
                        val nrrB = calculateNetRunRate(b.runsFor, b.ballsFaced, b.runsAgainst, b.ballsBowled)
                        nrrB.compareTo(nrrA)
                    }
                    "H2H" -> headToHeadCompare(a.id, b.id, matches)
                    "NAME" -> a.name.compareTo(b.name, ignoreCase = true)
                    else -> 0
                }
                if (cmp != 0) return@sortedWith cmp
            }
            a.name.compareTo(b.name, ignoreCase = true)
        }
    }

    fun resolveMatchLww(local: MatchEntity?, remote: MatchEntity): MatchEntity {
        return if (local == null || remote.updatedAt >= local.updatedAt) remote else local
    }
}
