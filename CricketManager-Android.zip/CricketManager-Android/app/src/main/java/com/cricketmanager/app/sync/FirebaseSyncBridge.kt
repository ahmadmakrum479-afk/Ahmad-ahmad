package com.cricketmanager.app.sync

import android.content.Context
import com.cricketmanager.app.data.local.TournamentEntity
import com.cricketmanager.app.domain.BackupSerializer
import com.cricketmanager.app.domain.TournamentBackupBundle
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.security.MessageDigest
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

sealed class CloudSyncResult {
    data class Synced(val syncedCount: Int) : CloudSyncResult()
    data object NotConfigured : CloudSyncResult()
    data class Error(val message: String) : CloudSyncResult()
}

data class PulledTournamentResult(
    val bundle: TournamentBackupBundle,
    val matchedAsEditor: Boolean
)

class FirebaseSyncBridge(private val context: Context) {

    companion object {
        const val FIRESTORE_DATABASE_ID = "ai-studio-cricketmanageran-6d588bd6-5aab-4158-b5e9-4c1f3d93d5c6"
    }

    fun isFirebaseConfigured(): Boolean {
        return runCatching {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context) != null
            } else {
                true
            }
        }.getOrDefault(false)
    }

    private fun firestore(): FirebaseFirestore {
        val app = FirebaseApp.getInstance()
        return FirebaseFirestore.getInstance(app, FIRESTORE_DATABASE_ID)
    }

    fun currentUser(): FirebaseUser? {
        if (!isFirebaseConfigured()) return null
        return runCatching { FirebaseAuth.getInstance().currentUser }.getOrNull()
    }

    fun currentUid(): String? = currentUser()?.uid

    fun isAnonymousUser(): Boolean = currentUser()?.isAnonymous == true

    fun isEmailSignedIn(): Boolean {
        val user = currentUser() ?: return false
        return !user.isAnonymous
    }

    fun signOutFirebase() {
        if (!isFirebaseConfigured()) return
        runCatching { FirebaseAuth.getInstance().signOut() }
    }

    suspend fun signInAnonymouslyIfNeeded(): Result<String> {
        if (!isFirebaseConfigured()) {
            return Result.failure(IllegalStateException("google-services.json not configured"))
        }
        val existing = currentUser()
        if (existing != null) {
            return Result.success(existing.uid)
        }
        return runCatching {
            val res = awaitTask(FirebaseAuth.getInstance().signInAnonymously())
            res.user?.uid ?: throw IllegalStateException("Anonymous login failed")
        }
    }

    suspend fun signInWithEmail(email: String, password: String): Result<String> {
        if (!isFirebaseConfigured()) {
            return Result.failure(IllegalStateException("google-services.json not configured"))
        }
        return runCatching {
            val res = awaitTask(FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password))
            res.user?.uid ?: throw IllegalStateException("Firebase login failed")
        }
    }

    suspend fun signInOrRegisterFirebase(email: String, password: String): Result<String> {
        if (!isFirebaseConfigured()) {
            return Result.failure(IllegalStateException("google-services.json not configured"))
        }
        return runCatching {
            val auth = FirebaseAuth.getInstance()
            val result = try {
                awaitTask(auth.signInWithEmailAndPassword(email, password))
            } catch (_: FirebaseAuthInvalidUserException) {
                awaitTask(auth.createUserWithEmailAndPassword(email, password))
            } catch (ex: FirebaseAuthInvalidCredentialsException) {
                // Newer Firebase projects enable email enumeration protection and throw InvalidCredentials for unknown emails
                try {
                    awaitTask(auth.createUserWithEmailAndPassword(email, password))
                } catch (_: Exception) {
                    throw ex
                }
            }
            result.user?.uid ?: throw IllegalStateException("Firebase authentication failed")
        }
    }

    fun hashEditorCode(editorCode: String): String {
        val normalized = "CM_ED:${editorCode.trim().uppercase()}"
        val digest = MessageDigest.getInstance("SHA-256").digest(normalized.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    suspend fun claimEditorAccess(tournamentCode: String, editorCode: String): Result<Unit> {
        if (!isFirebaseConfigured()) return Result.success(Unit)
        val uid = currentUid()
        if (uid.isNullOrBlank() || isAnonymousUser()) {
            return Result.failure(IllegalStateException("এডিটর অ্যাক্সেস পেতে ইমেইল দিয়ে লগইন করুন।"))
        }
        val cleanTCode = tournamentCode.trim().uppercase()
        val cleanEditorCode = editorCode.trim().uppercase()
        return runCatching {
            val db = firestore()
            val grantPayload = mapOf(
                "uid" to uid,
                "tournamentCode" to cleanTCode,
                "editorCode" to cleanEditorCode,
                "grantedAt" to System.currentTimeMillis()
            )
            awaitTask(
                db.collection("tournaments")
                    .document(cleanTCode)
                    .collection("editorGrants")
                    .document(uid)
                    .set(grantPayload)
            )
            Unit
        }
    }

    suspend fun pushTournamentBundle(
        bundle: TournamentBackupBundle,
        ownerUid: String,
        editorUids: List<String> = emptyList()
    ): CloudSyncResult {
        if (!isFirebaseConfigured()) {
            return CloudSyncResult.NotConfigured
        }
        val activeUser = currentUser()
        if (activeUser == null || activeUser.isAnonymous) {
            return CloudSyncResult.Error("ক্লাউডে সেভ করতে ইমেইল অ্যাকাউন্ট দিয়ে লগইন করুন।")
        }
        val effectiveUid = activeUser.uid
        return try {
            val firestore = firestore()
            val t = bundle.tournament
            val docRef = firestore.collection("tournaments").document(t.tournamentCode)
            val existingDoc = awaitTask(docRef.get())
            val existingOwnerUid = existingDoc.getString("ownerUid")
            val isOwnerWrite = !existingDoc.exists() || existingOwnerUid == null || existingOwnerUid == effectiveUid

            val redactedBundleJson = BackupSerializer.exportTournamentJson(bundle, redactEditorCode = true)
            val existingEditorUids = (existingDoc.get("editorUids") as? List<*>)
                ?.mapNotNull { it as? String }
                ?.distinct()
                ?.take(20)
                ?: emptyList()
            val resolvedOwnerUid = if (isOwnerWrite) effectiveUid else (existingOwnerUid ?: ownerUid)
            val resolvedEditorUids = if (isOwnerWrite) {
                (existingEditorUids + editorUids).distinct().take(20)
            } else {
                existingEditorUids
            }

            if (isOwnerWrite) {
                val payload = mapOf(
                    "localId" to t.id,
                    "name" to t.name,
                    "logoEmoji" to t.logoEmoji,
                    "pitchType" to t.pitchType.name,
                    "scoringMode" to t.scoringMode.name,
                    "format" to t.format.name,
                    "oversPerMatch" to t.oversPerMatch,
                    "tournamentCode" to t.tournamentCode,
                    "editorCodeHash" to hashEditorCode(t.editorCode),
                    "viewerCode" to t.viewerCode,
                    "ownerUid" to resolvedOwnerUid,
                    "editorUids" to resolvedEditorUids,
                    "isPublic" to true,
                    "updatedAt" to t.updatedAt,
                    "bundleJson" to redactedBundleJson
                )
                awaitTask(docRef.set(payload, SetOptions.merge()))

                val secretPayload = mapOf(
                    "ownerUid" to resolvedOwnerUid,
                    "tournamentCode" to t.tournamentCode,
                    "editorCode" to t.editorCode
                )
                awaitTask(docRef.collection("private").document("editorSecret").set(secretPayload))
            } else {
                val editorPayload = mapOf(
                    "localId" to t.id,
                    "name" to t.name,
                    "logoEmoji" to t.logoEmoji,
                    "pitchType" to t.pitchType.name,
                    "scoringMode" to t.scoringMode.name,
                    "format" to t.format.name,
                    "oversPerMatch" to t.oversPerMatch,
                    "isPublic" to true,
                    "updatedAt" to t.updatedAt,
                    "bundleJson" to redactedBundleJson
                )
                awaitTask(docRef.update(editorPayload))
            }

            val writeOps = mutableListOf<Pair<com.google.firebase.firestore.DocumentReference, Map<String, Any>>>()

            bundle.teams.forEach { team ->
                writeOps.add(
                    docRef.collection("teams").document(team.id.toString()) to mapOf(
                        "id" to team.id,
                        "tournamentCode" to t.tournamentCode,
                        "isPublic" to true,
                        "name" to team.name,
                        "shortCode" to team.shortCode,
                        "played" to team.played,
                        "won" to team.won,
                        "points" to team.points,
                        "updatedAt" to t.updatedAt
                    )
                )
            }

            bundle.players.forEach { player ->
                writeOps.add(
                    docRef.collection("players").document(player.id.toString()) to mapOf(
                        "id" to player.id,
                        "tournamentCode" to t.tournamentCode,
                        "isPublic" to true,
                        "teamId" to player.teamId,
                        "name" to player.name,
                        "runsScored" to player.runsScored,
                        "wicketsTaken" to player.wicketsTaken,
                        "updatedAt" to t.updatedAt
                    )
                )
            }

            bundle.matches.forEach { m ->
                writeOps.add(
                    docRef.collection("matches").document(m.matchNumber.toString()) to mapOf(
                        "id" to m.id,
                        "tournamentCode" to t.tournamentCode,
                        "isPublic" to true,
                        "matchNumber" to m.matchNumber,
                        "stage" to m.stage.name,
                        "teamAId" to m.teamAId,
                        "teamBId" to m.teamBId,
                        "teamARuns" to m.teamARuns,
                        "teamAWickets" to m.teamAWickets,
                        "teamABalls" to m.teamABalls,
                        "teamBRuns" to m.teamBRuns,
                        "teamBWickets" to m.teamBWickets,
                        "teamBBalls" to m.teamBBalls,
                        "status" to m.status.name,
                        "winnerTeamId" to m.winnerTeamId,
                        "resultSummary" to m.resultSummary,
                        "updatedAt" to m.updatedAt
                    )
                )
            }

            bundle.members.forEach { mem ->
                writeOps.add(
                    docRef.collection("members").document(mem.userId.toString()) to mapOf(
                        "userId" to mem.userId,
                        "tournamentCode" to t.tournamentCode,
                        "ownerUid" to resolvedOwnerUid,
                        "editorUids" to resolvedEditorUids,
                        "userName" to mem.userName,
                        "userEmail" to mem.userEmail,
                        "role" to mem.role.name,
                        "canScore" to mem.canScore
                    )
                )
            }

            bundle.balls.forEachIndexed { idx, ball ->
                writeOps.add(
                    docRef.collection("balls").document("${ball.matchId}_${ball.innings}_${ball.sequenceNumber}_$idx") to mapOf(
                        "tournamentCode" to t.tournamentCode,
                        "isPublic" to true,
                        "matchId" to ball.matchId,
                        "innings" to ball.innings,
                        "sequenceNumber" to ball.sequenceNumber,
                        "summaryLabel" to ball.summaryLabel,
                        "timestamp" to ball.timestamp
                    )
                )
            }

            bundle.logs.take(50).forEachIndexed { idx, log ->
                writeOps.add(
                    docRef.collection("auditLogs").document("${log.createdAt}_$idx") to mapOf(
                        "tournamentCode" to t.tournamentCode,
                        "isPublic" to true,
                        "actorName" to log.actorName,
                        "actionTitle" to log.actionTitle,
                        "details" to log.details,
                        "createdAt" to log.createdAt
                    )
                )
            }

            writeOps.chunked(400).forEach { chunk ->
                val batch = firestore.batch()
                chunk.forEach { (ref, map) -> batch.set(ref, map, SetOptions.merge()) }
                awaitTask(batch.commit())
            }

            CloudSyncResult.Synced(1)
        } catch (e: Exception) {
            CloudSyncResult.Error(e.message ?: "Cloud sync error")
        }
    }

    suspend fun pushDirtyBundles(
        bundles: List<TournamentBackupBundle>,
        ownerUid: String
    ): CloudSyncResult {
        if (!isFirebaseConfigured()) {
            return CloudSyncResult.NotConfigured
        }
        var syncedCount = 0
        for (bundle in bundles) {
            when (val res = pushTournamentBundle(bundle, ownerUid)) {
                is CloudSyncResult.Synced -> syncedCount += res.syncedCount
                is CloudSyncResult.Error -> return res
                CloudSyncResult.NotConfigured -> return CloudSyncResult.NotConfigured
            }
        }
        return CloudSyncResult.Synced(syncedCount)
    }

    suspend fun pullTournamentByCode(code: String, currentUserId: Long): Result<PulledTournamentResult?> {
        if (!isFirebaseConfigured()) {
            return Result.success(null)
        }
        val clean = code.trim().uppercase()
        return runCatching {
            signInAnonymouslyIfNeeded().getOrThrow()
            val firestore = firestore()
            val tournamentsRef = firestore.collection("tournaments")
            var doc: DocumentSnapshot? = null
            var matchedAsEditor = false

            val direct = awaitTask(tournamentsRef.document(clean).get())
            if (direct.exists()) {
                doc = direct
            }
            if (doc == null) {
                val byViewer = awaitTask(
                    tournamentsRef
                        .whereEqualTo("isPublic", true)
                        .whereEqualTo("viewerCode", clean)
                        .limit(1)
                        .get()
                )
                doc = byViewer.documents.firstOrNull()
            }
            if (doc == null) {
                val byEditorHash = awaitTask(
                    tournamentsRef
                        .whereEqualTo("isPublic", true)
                        .whereEqualTo("editorCodeHash", hashEditorCode(clean))
                        .limit(1)
                        .get()
                )
                doc = byEditorHash.documents.firstOrNull()
                if (doc != null) {
                    matchedAsEditor = true
                }
            }
            val found = doc ?: return@runCatching null
            val bundleJson = found.getString("bundleJson") ?: return@runCatching null
            val parsed = BackupSerializer.parseTournamentJson(bundleJson, currentUserId)
            val cloudTournament = parsed.tournament.copy(
                tournamentCode = found.getString("tournamentCode") ?: parsed.tournament.tournamentCode,
                editorCode = if (matchedAsEditor) clean else parsed.tournament.editorCode,
                viewerCode = found.getString("viewerCode") ?: parsed.tournament.viewerCode,
                updatedAt = found.getLong("updatedAt") ?: parsed.tournament.updatedAt,
                syncDirty = false
            )
            PulledTournamentResult(
                bundle = parsed.copy(tournament = cloudTournament),
                matchedAsEditor = matchedAsEditor
            )
        }
    }

    suspend fun pullLatestBundleIfNewer(
        tournamentCode: String,
        localUpdatedAt: Long,
        currentUserId: Long
    ): Result<TournamentBackupBundle?> {
        if (!isFirebaseConfigured()) return Result.success(null)
        return runCatching {
            signInAnonymouslyIfNeeded().getOrThrow()
            val doc = awaitTask(
                firestore().collection("tournaments").document(tournamentCode.trim().uppercase()).get()
            )
            if (!doc.exists()) return@runCatching null
            val remoteUpdatedAt = doc.getLong("updatedAt") ?: 0L
            if (remoteUpdatedAt <= localUpdatedAt) return@runCatching null
            val bundleJson = doc.getString("bundleJson") ?: return@runCatching null
            val parsed = BackupSerializer.parseTournamentJson(bundleJson, currentUserId)
            val cloudTournament = parsed.tournament.copy(
                tournamentCode = doc.getString("tournamentCode") ?: parsed.tournament.tournamentCode,
                viewerCode = doc.getString("viewerCode") ?: parsed.tournament.viewerCode,
                updatedAt = remoteUpdatedAt,
                syncDirty = false
            )
            parsed.copy(tournament = cloudTournament)
        }
    }

    private suspend fun <T> awaitTask(task: Task<T>): T = suspendCancellableCoroutine { cont ->
        task.addOnSuccessListener { result ->
            if (cont.isActive) cont.resume(result)
        }.addOnFailureListener { ex ->
            if (cont.isActive) cont.resumeWithException(ex)
        }
    }
}
