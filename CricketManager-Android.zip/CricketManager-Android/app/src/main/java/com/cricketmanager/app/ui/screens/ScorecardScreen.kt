package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.BallEventEntity
import com.cricketmanager.app.data.local.ExtraType
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerMatchStatEntity
import com.cricketmanager.app.data.local.WicketType
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.AppLanguage
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScorecardScreen(
    matchId: Long,
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onBack: () -> Unit,
    onOpenLiveScoring: () -> Unit,
    onOpenManualScoring: () -> Unit
) {
    val strings = LocalAppStrings.current
    val isBn = strings.language == AppLanguage.BN
    val match = uiState.allMatches.firstOrNull { it.id == matchId }

    if (match == null) {
        Scaffold(topBar = { ScreenTopBar(title = strings.scorecard, onBack = onBack) }) { p ->
            Text("Match not found", modifier = Modifier.padding(p).padding(20.dp))
        }
        return
    }

    val tournament = uiState.tournaments.firstOrNull { it.id == match.tournamentId }
    val playersPerSideLimit = CricketStatsEngine.effectivePlayersPerSideForMatch(match, tournament)
    val players = uiState.allPlayers.filter { it.tournamentId == match.tournamentId }
    val teamAFullSquad = players.filter { it.teamId == match.teamAId }
    val teamBFullSquad = players.filter { it.teamId == match.teamBId }
    val savedAPlayingIds = CricketStatsEngine.parsePlayingIds(match.teamAPlayingIds)
    val savedBPlayingIds = CricketStatsEngine.parsePlayingIds(match.teamBPlayingIds)
    val balls = uiState.allBallEvents.filter { it.matchId == match.id }
    val manualStats = uiState.allPlayerMatchStats.filter { it.matchId == match.id }
    val perms = uiState.permissionsFor(match.tournamentId)

    var showPlayingXiDialog by remember { mutableStateOf(false) }
    var playingXiError by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            ScreenTopBar(
                title = strings.scorecard,
                subtitle = "${match.teamAName} vs ${match.teamBName}",
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Match #${match.matchNumber} · ${match.stage.labelEn}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(match.teamAName, fontWeight = FontWeight.Bold)
                            Text("${match.teamARuns}/${match.teamAWickets} (${CricketStatsEngine.formatOvers(match.teamABalls)} ov) · Ext ${match.teamAExtras}", fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(match.teamBName, fontWeight = FontWeight.Bold)
                            Text("${match.teamBRuns}/${match.teamBWickets} (${CricketStatsEngine.formatOvers(match.teamBBalls)} ov) · Ext ${match.teamBExtras}", fontWeight = FontWeight.Bold)
                        }
                        Text(match.resultSummary, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        if (match.playerOfMatchName.isNotBlank()) {
                            val impactMap = CricketStatsEngine.calculateMatchStatsImpact(manualStats, tournament)
                            val pomScore = impactMap[match.playerOfMatchId]?.totalScore ?: 0.0
                            val ptsSuffix = if (pomScore > 0.0) String.format(Locale.US, " (Impact %.2f)", pomScore) else ""
                            Text("⭐ Man of the Match: ${match.playerOfMatchName}$ptsSuffix", style = MaterialTheme.typography.labelMedium)
                        }
                        if (perms.canScore) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                if (match.status != MatchStatus.COMPLETED && match.status != MatchStatus.ABANDONED) {
                                    Button(onClick = onOpenLiveScoring, modifier = Modifier.weight(1f)) {
                                        Text(strings.liveScoring)
                                    }
                                }
                                OutlinedButton(onClick = onOpenManualScoring, modifier = Modifier.weight(1f)) {
                                    Text("Edit Scorecard")
                                }
                            }
                            OutlinedButton(
                                onClick = {
                                    playingXiError = null
                                    showPlayingXiDialog = true
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    if (isBn) {
                                        "একাদশ সম্পাদনা (${savedAPlayingIds.size}/$playersPerSideLimit · ${savedBPlayingIds.size}/$playersPerSideLimit)"
                                    } else {
                                        "Edit Playing XI (${savedAPlayingIds.size}/$playersPerSideLimit · ${savedBPlayingIds.size}/$playersPerSideLimit)"
                                    }
                                )
                            }
                        }
                    }
                }
            }

            val firstBatIsB = match.battingFirstTeamId == match.teamBId
            val firstBatTeamId = if (firstBatIsB) match.teamBId else match.teamAId
            val secondBatTeamId = if (firstBatIsB) match.teamAId else match.teamBId
            val firstBatTeamName = if (firstBatIsB) match.teamBName else match.teamAName
            val secondBatTeamName = if (firstBatIsB) match.teamAName else match.teamBName

            item {
                InningsBreakdownCard(
                    title = "$firstBatTeamName — 1st Innings",
                    inningsBalls = balls.filter { it.innings == 1 },
                    battingTeamStats = manualStats.filter { it.teamId == firstBatTeamId },
                    bowlingTeamStats = manualStats.filter { it.teamId == secondBatTeamId },
                    players = players
                )
            }

            item {
                InningsBreakdownCard(
                    title = "$secondBatTeamName — 2nd Innings",
                    inningsBalls = balls.filter { it.innings == 2 },
                    battingTeamStats = manualStats.filter { it.teamId == secondBatTeamId },
                    bowlingTeamStats = manualStats.filter { it.teamId == firstBatTeamId },
                    players = players
                )
            }
        }
    }

    if (showPlayingXiDialog) {
        var draftAIds by remember(match.id, showPlayingXiDialog) {
            mutableStateOf(savedAPlayingIds)
        }
        var draftBIds by remember(match.id, showPlayingXiDialog) {
            mutableStateOf(savedBPlayingIds)
        }
        val errA = CricketStatsEngine.validatePlayingSelection(draftAIds, playersPerSideLimit)
        val errB = CricketStatsEngine.validatePlayingSelection(draftBIds, playersPerSideLimit)
        val activeErr = errA?.let { "${match.teamAName}: $it" }
            ?: errB?.let { "${match.teamBName}: $it" }
            ?: playingXiError

        AlertDialog(
            onDismissRequest = { showPlayingXiDialog = false },
            title = {
                Text(if (isBn) "একাদশ সম্পাদনা (ঠিক $playersPerSideLimit জন)" else "Edit Playing XI (Exact $playersPerSideLimit)")
            },
            text = {
                LazyColumn(modifier = Modifier.height(340.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (activeErr != null) {
                        item {
                            Text(
                                text = activeErr,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    item {
                        Text(
                            "${match.teamAName} (${draftAIds.size} / $playersPerSideLimit)",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    item {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            teamAFullSquad.forEach { p ->
                                val selected = p.id in draftAIds
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        playingXiError = null
                                        draftAIds = if (selected) draftAIds - p.id else draftAIds + p.id
                                    },
                                    label = { Text(p.name) }
                                )
                            }
                        }
                    }
                    item {
                        Text(
                            "${match.teamBName} (${draftBIds.size} / $playersPerSideLimit)",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    item {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            teamBFullSquad.forEach { p ->
                                val selected = p.id in draftBIds
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        playingXiError = null
                                        draftBIds = if (selected) draftBIds - p.id else draftBIds + p.id
                                    },
                                    label = { Text(p.name) }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val vA = CricketStatsEngine.validatePlayingSelection(draftAIds, playersPerSideLimit)
                    if (vA != null) {
                        playingXiError = "${match.teamAName}: $vA"
                        return@Button
                    }
                    val vB = CricketStatsEngine.validatePlayingSelection(draftBIds, playersPerSideLimit)
                    if (vB != null) {
                        playingXiError = "${match.teamBName}: $vB"
                        return@Button
                    }
                    viewModel.saveMatchPlayingSquad(
                        matchId = match.id,
                        teamAIds = draftAIds,
                        teamBIds = draftBIds,
                        onError = { playingXiError = it },
                        onSaved = { showPlayingXiDialog = false }
                    )
                }) { Text(strings.save) }
            },
            dismissButton = { TextButton(onClick = { showPlayingXiDialog = false }) { Text(strings.cancel) } }
        )
    }
}

@Composable
private fun InningsBreakdownCard(
    title: String,
    inningsBalls: List<BallEventEntity>,
    battingTeamStats: List<PlayerMatchStatEntity>,
    bowlingTeamStats: List<PlayerMatchStatEntity>,
    players: List<PlayerEntity>
) {
    val hasManualBat = battingTeamStats.any { it.didBat || it.runsScored > 0 || it.ballsFaced > 0 }
    val hasManualBowl = bowlingTeamStats.any { it.didBowl || it.ballsBowled > 0 || it.wicketsTaken > 0 }

    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (!hasManualBat && !hasManualBowl && inningsBalls.isEmpty()) {
                Text("No individual player stats recorded yet. Tap Edit Scorecard to add.", style = MaterialTheme.typography.bodySmall)
                return@Column
            }

            Text("Batting", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            if (hasManualBat) {
                battingTeamStats.filter { it.didBat || it.runsScored > 0 || it.ballsFaced > 0 }.forEach { st ->
                    val sr = CricketStatsEngine.calculateStrikeRate(st.runsScored, st.ballsFaced)
                    val notOutMark = if (st.isNotOut) "*" else ""
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${st.playerName}$notOutMark", modifier = Modifier.weight(1f))
                        Text(
                            String.format(Locale.US, "%d (%d)  4s:%d 6s:%d  SR:%.1f", st.runsScored, st.ballsFaced, st.fours, st.sixes, sr),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            } else {
                val batters = inningsBalls.groupBy { it.strikerId }.filterKeys { it > 0L }
                batters.forEach { (batterId, list) ->
                    val name = players.firstOrNull { it.id == batterId }?.name ?: "Batter"
                    val runs = list.sumOf { it.runsOffBat }
                    val ballsFaced = list.count { it.extraType != ExtraType.WIDE }
                    val fours = list.count { it.isBoundaryFour }
                    val sixes = list.count { it.isBoundarySix }
                    val sr = CricketStatsEngine.calculateStrikeRate(runs, ballsFaced)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name, modifier = Modifier.weight(1f))
                        Text(
                            String.format(Locale.US, "%d (%d)  4s:%d 6s:%d  SR:%.1f", runs, ballsFaced, fours, sixes, sr),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            HorizontalDivider()
            Text("Bowling", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            if (hasManualBowl) {
                bowlingTeamStats.filter { it.didBowl || it.ballsBowled > 0 || it.wicketsTaken > 0 }.forEach { st ->
                    val econ = CricketStatsEngine.calculateEconomyRate(st.runsConceded, st.ballsBowled)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(st.playerName, modifier = Modifier.weight(1f))
                        Text(
                            String.format(Locale.US, "%s ov  %d-%d  Econ:%.2f", CricketStatsEngine.formatOvers(st.ballsBowled), st.wicketsTaken, st.runsConceded, econ),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            } else {
                val bowlers = inningsBalls.groupBy { it.bowlerId }.filterKeys { it > 0L }
                bowlers.forEach { (bowlerId, list) ->
                    val name = players.firstOrNull { it.id == bowlerId }?.name ?: "Bowler"
                    val legalBalls = list.count { CricketStatsEngine.isLegalDelivery(it.extraType) }
                    val conceded = list.sumOf {
                        if (it.extraType == ExtraType.BYE || it.extraType == ExtraType.LEG_BYE) 0 else it.runsOffBat + it.extraRuns
                    }
                    val wkts = list.count { it.isWicket && it.wicketType != WicketType.RUN_OUT }
                    val econ = CricketStatsEngine.calculateEconomyRate(conceded, legalBalls)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name, modifier = Modifier.weight(1f))
                        Text(
                            String.format(Locale.US, "%s ov  %d-%d  Econ:%.2f", CricketStatsEngine.formatOvers(legalBalls), wkts, conceded, econ),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
