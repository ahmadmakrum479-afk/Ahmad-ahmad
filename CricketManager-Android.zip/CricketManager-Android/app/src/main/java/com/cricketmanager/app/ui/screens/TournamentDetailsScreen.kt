package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Leaderboard
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.MatchStage
import com.cricketmanager.app.data.local.PitchType
import com.cricketmanager.app.data.local.PlayoffType
import com.cricketmanager.app.data.local.TieRule
import com.cricketmanager.app.data.local.TiebreakerCriterion
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.AppLanguage
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

@OptIn(ExperimentalLayoutApi::class)

@Composable
fun TournamentDetailsScreen(
    tournamentId: Long,
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onBack: () -> Unit,
    onOpenTeams: () -> Unit,
    onOpenPlayers: () -> Unit,
    onOpenSchedule: () -> Unit,
    onOpenPoints: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenPermissions: () -> Unit
) {
    val strings = LocalAppStrings.current
    val clipboard = LocalClipboardManager.current
    val tournament = uiState.tournaments.firstOrNull { it.id == tournamentId } ?: uiState.selectedTournament

    LaunchedEffect(tournamentId) {
        if (tournamentId > 0L) viewModel.selectTournament(tournamentId)
    }

    Scaffold(
        topBar = {
            ScreenTopBar(
                title = tournament?.let { "${it.logoEmoji} ${it.name}" } ?: strings.tournamentDetails,
                subtitle = tournament?.let { "${it.format.labelEn} · ${it.scoringMode.labelEn}" },
                onBack = onBack
            )
        }
    ) { padding ->
        if (tournament == null) {
            Column(modifier = Modifier.padding(padding).padding(20.dp)) {
                Text(strings.noTournamentsYet)
            }
            return@Scaffold
        }

        val isBn = strings.language == AppLanguage.BN
        val perms = uiState.permissionsFor(tournament.id)
        val teamCount = uiState.allTeams.count { it.tournamentId == tournament.id }
        val playerCount = uiState.allPlayers.count { it.tournamentId == tournament.id }
        val matchCount = uiState.allMatches.count { it.tournamentId == tournament.id }
        var showEditRulesDialog by remember { mutableStateOf(false) }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "${tournament.organizationName.ifBlank { "Cricket Organizer" }} · ${tournament.location}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${tournament.pitchType.labelEn} · ${tournament.oversPerMatch} Overs · ${tournament.playersPerSide} Players (All-out ${tournament.allOutWickets}) · Max ${tournament.maxOversPerBowler} ov/bowler",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Points: W ${tournament.pointsWin} / T ${tournament.pointsTie} / L ${tournament.pointsLoss} / NR ${tournament.pointsAbandoned} / WO ${tournament.pointsWalkover} · ${tournament.tieRule.labelEn} · ${tournament.matchesPerPair}x · ${tournament.playoffType.labelEn} (Top ${tournament.playoffTeamsCount})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        val stageOverrideHasAny = tournament.leaguePlayersPerSide > 0 ||
                            tournament.leagueSquadSize > 0 ||
                            tournament.leagueOvers > 0 ||
                            tournament.playoffPlayersPerSide > 0 ||
                            tournament.playoffSquadSize > 0 ||
                            tournament.playoffOvers > 0 ||
                            tournament.finalPlayersPerSide > 0 ||
                            tournament.finalSquadSize > 0 ||
                            tournament.finalOvers > 0
                        if (stageOverrideHasAny) {
                            val lp = if (tournament.leaguePlayersPerSide > 0) tournament.leaguePlayersPerSide else tournament.playersPerSide
                            val lsq = if (tournament.leagueSquadSize > 0) tournament.leagueSquadSize else tournament.squadSize
                            val lov = if (tournament.leagueOvers > 0) tournament.leagueOvers else tournament.oversPerMatch
                            val pp = if (tournament.playoffPlayersPerSide > 0) tournament.playoffPlayersPerSide else tournament.playersPerSide
                            val psq = if (tournament.playoffSquadSize > 0) tournament.playoffSquadSize else tournament.squadSize
                            val pov = if (tournament.playoffOvers > 0) tournament.playoffOvers else tournament.oversPerMatch
                            val fp = if (tournament.finalPlayersPerSide > 0) tournament.finalPlayersPerSide else tournament.playersPerSide
                            val fsq = if (tournament.finalSquadSize > 0) tournament.finalSquadSize else tournament.squadSize
                            val fov = if (tournament.finalOvers > 0) tournament.finalOvers else tournament.oversPerMatch
                            Text(
                                text = "Stage Overrides — League: ${lp}p/${lsq}sq/${lov}ov · Play-off: ${pp}p/${psq}sq/${pov}ov · Final: ${fp}p/${fsq}sq/${fov}ov",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = CricketStatsEngine.formatRulesSummary(tournament),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (perms.canEditSchedule) {
                            OutlinedButton(
                                onClick = { showEditRulesDialog = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Rounded.Edit, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text(if (isBn) "টুর্নামেন্টের নিয়ম পরিবর্তন করুন" else "Edit Tournament Rules")
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Join Code: ${tournament.tournamentCode}  |  Viewer: ${tournament.viewerCode}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(tournament.tournamentCode))
                                }
                            ) {
                                Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy code")
                            }
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    HubTile(
                        title = strings.teams,
                        subtitle = "$teamCount Teams",
                        icon = Icons.Rounded.Groups,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenTeams
                    )
                    HubTile(
                        title = strings.players,
                        subtitle = "$playerCount Players",
                        icon = Icons.Rounded.Person,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenPlayers
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    HubTile(
                        title = strings.schedule,
                        subtitle = "$matchCount Matches",
                        icon = Icons.Rounded.CalendarMonth,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenSchedule
                    )
                    HubTile(
                        title = strings.pointsTable,
                        subtitle = "Standings & NRR",
                        icon = Icons.Rounded.Leaderboard,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenPoints
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    HubTile(
                        title = strings.statistics,
                        subtitle = "MVP & Leaderboards",
                        icon = Icons.Rounded.BarChart,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenStats
                    )
                    HubTile(
                        title = strings.permissions,
                        subtitle = "Role: ${perms.role.labelEn}",
                        icon = Icons.Rounded.AdminPanelSettings,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenPermissions
                    )
                }
            }

            if (perms.canEditSchedule) {
                item {
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = if (isBn) "প্লে-অফ ও ফাইনাল তৈরি (${tournament.playoffType.labelBn})" else "Play-off Stage Generator (${tournament.playoffType.labelEn})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            when (tournament.playoffType) {
                                PlayoffType.NONE -> {
                                    Text(
                                        text = if (isBn) "এই টুর্নামেন্টে কোনো প্লে-অফ নেই।" else "No play-offs configured for this tournament.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                PlayoffType.FINAL_ONLY -> {
                                    Button(
                                        onClick = { viewModel.generateStage(tournament, MatchStage.FINAL) },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(strings.generateFinal)
                                    }
                                }
                                PlayoffType.SEMI_FINAL -> {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(
                                            onClick = { viewModel.generateStage(tournament, MatchStage.SEMI_FINAL) },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(strings.generateSemiFinal)
                                        }
                                        Button(
                                            onClick = { viewModel.generateStage(tournament, MatchStage.FINAL) },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(strings.generateFinal)
                                        }
                                    }
                                }
                                PlayoffType.QUALIFIER_ELIMINATOR -> {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(
                                            onClick = { viewModel.generateStage(tournament, MatchStage.QUALIFIER_1) },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(if (isBn) "কোয়ালিফায়ার-১" else "Qualifier 1")
                                        }
                                        OutlinedButton(
                                            onClick = { viewModel.generateStage(tournament, MatchStage.ELIMINATOR) },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(if (isBn) "এলিমিনেটর" else "Eliminator")
                                        }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(
                                            onClick = { viewModel.generateStage(tournament, MatchStage.QUALIFIER_2) },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(if (isBn) "কোয়ালিফায়ার-২" else "Qualifier 2")
                                        }
                                        Button(
                                            onClick = { viewModel.generateStage(tournament, MatchStage.FINAL) },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(strings.generateFinal)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showEditRulesDialog) {
            var ePlayers by remember(tournament.id) { mutableStateOf(tournament.playersPerSide.toString()) }
            var eSquad by remember(tournament.id) { mutableStateOf(tournament.squadSize.toString()) }
            var eOvers by remember(tournament.id) { mutableStateOf(tournament.oversPerMatch.toString()) }
            var eAllOut by remember(tournament.id) { mutableStateOf(tournament.allOutWickets.toString()) }
            var eMaxBowl by remember(tournament.id) { mutableStateOf(tournament.maxOversPerBowler.toString()) }
            var eWin by remember(tournament.id) { mutableStateOf(tournament.pointsWin.toString()) }
            var eTie by remember(tournament.id) { mutableStateOf(tournament.pointsTie.toString()) }
            var eLoss by remember(tournament.id) { mutableStateOf(tournament.pointsLoss.toString()) }
            var eAbandon by remember(tournament.id) { mutableStateOf(tournament.pointsAbandoned.toString()) }
            var eWalkover by remember(tournament.id) { mutableStateOf(tournament.pointsWalkover.toString()) }
            var ePitch by remember(tournament.id) { mutableStateOf(tournament.pitchType) }
            var eTieRule by remember(tournament.id) { mutableStateOf(tournament.tieRule) }
            var ePairs by remember(tournament.id) { mutableStateOf(tournament.matchesPerPair) }
            var ePlayoffType by remember(tournament.id) { mutableStateOf(tournament.playoffType) }
            var ePlayoffTop by remember(tournament.id) { mutableStateOf(tournament.playoffTeamsCount.toString()) }
            var eLeaguePlayers by remember(tournament.id) { mutableStateOf(if (tournament.leaguePlayersPerSide > 0) tournament.leaguePlayersPerSide.toString() else "") }
            var eLeagueSquad by remember(tournament.id) { mutableStateOf(if (tournament.leagueSquadSize > 0) tournament.leagueSquadSize.toString() else "") }
            var eLeagueOvers by remember(tournament.id) { mutableStateOf(if (tournament.leagueOvers > 0) tournament.leagueOvers.toString() else "") }
            var ePlayoffPlayers by remember(tournament.id) { mutableStateOf(if (tournament.playoffPlayersPerSide > 0) tournament.playoffPlayersPerSide.toString() else "") }
            var ePlayoffSquad by remember(tournament.id) { mutableStateOf(if (tournament.playoffSquadSize > 0) tournament.playoffSquadSize.toString() else "") }
            var ePlayoffOvers by remember(tournament.id) { mutableStateOf(if (tournament.playoffOvers > 0) tournament.playoffOvers.toString() else "") }
            var eFinalPlayers by remember(tournament.id) { mutableStateOf(if (tournament.finalPlayersPerSide > 0) tournament.finalPlayersPerSide.toString() else "") }
            var eFinalSquad by remember(tournament.id) { mutableStateOf(if (tournament.finalSquadSize > 0) tournament.finalSquadSize.toString() else "") }
            var eFinalOvers by remember(tournament.id) { mutableStateOf(if (tournament.finalOvers > 0) tournament.finalOvers.toString() else "") }
            var eMottBat by remember(tournament.id) { mutableStateOf(tournament.mottBattingWeight.toString()) }
            var eMottBowl by remember(tournament.id) { mutableStateOf(tournament.mottBowlingWeight.toString()) }
            var eMottWktShare by remember(tournament.id) { mutableStateOf(tournament.mottBowlingWicketShare.toString()) }
            var eMottEconShare by remember(tournament.id) { mutableStateOf(tournament.mottBowlingEconomyShare.toString()) }
            var eMottFinalMult by remember(tournament.id) { mutableStateOf(tournament.mottFinalMultiplier.toString()) }
            val eTiebreakers = remember(tournament.id) {
                mutableStateListOf<String>().apply {
                    addAll(tournament.tiebreakerOrder.split(",").map { it.trim() }.filter { it.isNotEmpty() })
                    if (isEmpty()) addAll(listOf("POINTS", "WINS", "NRR", "H2H", "NAME"))
                }
            }

            AlertDialog(
                onDismissRequest = { showEditRulesDialog = false },
                title = { Text(if (isBn) "টুর্নামেন্টের নিয়ম সেটিংস" else "Tournament Rules Settings") },
                text = {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = ePlayers, onValueChange = { ePlayers = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "খেলোয়াড়" else "Players") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eSquad, onValueChange = { eSquad = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "স্কোয়াড" else "Squad") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eOvers, onValueChange = { eOvers = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "ওভার" else "Overs") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = eAllOut, onValueChange = { eAllOut = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "অল-আউট" else "All-Out") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eMaxBowl, onValueChange = { eMaxBowl = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "বোলার ম্যাক্স" else "Max Bowl") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = ePlayoffTop, onValueChange = { ePlayoffTop = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "শীর্ষ দল" else "Top N") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedTextField(value = eWin, onValueChange = { eWin = it.filter { c -> c.isDigit() } }, label = { Text("W") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eTie, onValueChange = { eTie = it.filter { c -> c.isDigit() } }, label = { Text("T") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eLoss, onValueChange = { eLoss = it.filter { c -> c.isDigit() } }, label = { Text("L") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eAbandon, onValueChange = { eAbandon = it.filter { c -> c.isDigit() } }, label = { Text("NR") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eWalkover, onValueChange = { eWalkover = it.filter { c -> c.isDigit() } }, label = { Text("WO") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PitchType.entries.forEach { pt ->
                                FilterChip(selected = ePitch == pt, onClick = { ePitch = pt }, label = { Text(if (isBn) pt.labelBn else pt.labelEn) })
                            }
                            TieRule.entries.forEach { tr ->
                                FilterChip(selected = eTieRule == tr, onClick = { eTieRule = tr }, label = { Text(if (isBn) tr.labelBn else tr.labelEn) })
                            }
                            listOf(1, 2).forEach { cnt ->
                                FilterChip(selected = ePairs == cnt, onClick = { ePairs = cnt }, label = { Text("${cnt}x") })
                            }
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PlayoffType.entries.forEach { po ->
                                FilterChip(selected = ePlayoffType == po, onClick = { ePlayoffType = po }, label = { Text(if (isBn) po.labelBn else po.labelEn) })
                            }
                        }
                        Text(if (isBn) "টাইব্রেকার ক্রম" else "Tiebreaker Order", style = MaterialTheme.typography.labelMedium)
                        eTiebreakers.forEachIndexed { idx, key ->
                            val crit = runCatching { TiebreakerCriterion.valueOf(key) }.getOrNull()
                            val lbl = crit?.let { if (isBn) it.labelBn else it.labelEn } ?: key
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("${idx + 1}. $lbl")
                                Row {
                                    IconButton(onClick = { if (idx > 0) { val x = eTiebreakers.removeAt(idx); eTiebreakers.add(idx - 1, x) } }, enabled = idx > 0) {
                                        Icon(Icons.Rounded.ArrowUpward, contentDescription = null)
                                    }
                                    IconButton(onClick = { if (idx < eTiebreakers.lastIndex) { val x = eTiebreakers.removeAt(idx); eTiebreakers.add(idx + 1, x) } }, enabled = idx < eTiebreakers.lastIndex) {
                                        Icon(Icons.Rounded.ArrowDownward, contentDescription = null)
                                    }
                                }
                            }
                        }
                        Text(
                            text = if (isBn) "পর্ব অনুযায়ী আলাদা নিয়ম (০ বা খালি = টুর্নামেন্টের মান)" else "Stage-Specific Rules (0 or blank = Tournament Default)",
                            style = MaterialTheme.typography.labelMedium
                        )
                        Text(if (isBn) "লিগ / গ্রুপ পর্ব" else "League / Group", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedTextField(value = eLeaguePlayers, onValueChange = { eLeaguePlayers = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "খেলোয়াড়" else "Players") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eLeagueSquad, onValueChange = { eLeagueSquad = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "স্কোয়াড" else "Squad") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eLeagueOvers, onValueChange = { eLeagueOvers = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "ওভার" else "Overs") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Text(if (isBn) "প্লে-অফ / সেমিফাইনাল" else "Play-off / Semi-Final", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedTextField(value = ePlayoffPlayers, onValueChange = { ePlayoffPlayers = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "খেলোয়াড়" else "Players") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = ePlayoffSquad, onValueChange = { ePlayoffSquad = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "স্কোয়াড" else "Squad") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = ePlayoffOvers, onValueChange = { ePlayoffOvers = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "ওভার" else "Overs") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Text(if (isBn) "ফাইনাল ম্যাচ" else "Final Match", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedTextField(value = eFinalPlayers, onValueChange = { eFinalPlayers = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "খেলোয়াড়" else "Players") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eFinalSquad, onValueChange = { eFinalSquad = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "স্কোয়াড" else "Squad") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eFinalOvers, onValueChange = { eFinalOvers = it.filter { c -> c.isDigit() } }, label = { Text(if (isBn) "ওভার" else "Overs") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Text(if (isBn) "MOTT ওজন (ব্যাট / বোল / ফাইনাল / উইকেট / ইকোনমি)" else "MOTT Weights", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedTextField(value = eMottBat, onValueChange = { eMottBat = it }, label = { Text("Bat") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eMottBowl, onValueChange = { eMottBowl = it }, label = { Text("Bowl") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eMottFinalMult, onValueChange = { eMottFinalMult = it }, label = { Text("Fin×") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedTextField(value = eMottWktShare, onValueChange = { eMottWktShare = it }, label = { Text("Wkt%") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = eMottEconShare, onValueChange = { eMottEconShare = it }, label = { Text("Eco%") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val p = (ePlayers.toIntOrNull() ?: tournament.playersPerSide).coerceIn(2, 15)
                        val sq = (eSquad.toIntOrNull() ?: tournament.squadSize).coerceIn(p, 30)
                        val ov = (eOvers.toIntOrNull() ?: tournament.oversPerMatch).coerceIn(1, 50)
                        val ao = (eAllOut.toIntOrNull() ?: p).coerceIn(1, p)
                        val mb = (eMaxBowl.toIntOrNull() ?: tournament.maxOversPerBowler).coerceIn(1, ov)
                        viewModel.updateTournamentRules(
                            tournament.copy(
                                playersPerSide = p,
                                squadSize = sq,
                                oversPerMatch = ov,
                                allOutWickets = ao,
                                maxOversPerBowler = mb,
                                rulesSummary = CricketStatsEngine.formatRulesSummary(ov, ePitch, p, ao, mb),
                                pointsWin = eWin.toIntOrNull() ?: tournament.pointsWin,
                                pointsTie = eTie.toIntOrNull() ?: tournament.pointsTie,
                                pointsLoss = eLoss.toIntOrNull() ?: tournament.pointsLoss,
                                pointsAbandoned = eAbandon.toIntOrNull() ?: tournament.pointsAbandoned,
                                pointsWalkover = eWalkover.toIntOrNull() ?: tournament.pointsWalkover,
                                pitchType = ePitch,
                                tieRule = eTieRule,
                                matchesPerPair = ePairs,
                                playoffType = ePlayoffType,
                                playoffTeamsCount = (ePlayoffTop.toIntOrNull() ?: tournament.playoffTeamsCount).coerceIn(2, 16),
                                leaguePlayersPerSide = (eLeaguePlayers.toIntOrNull() ?: 0).coerceAtLeast(0),
                                leagueSquadSize = (eLeagueSquad.toIntOrNull() ?: 0).coerceAtLeast(0),
                                leagueOvers = (eLeagueOvers.toIntOrNull() ?: 0).coerceAtLeast(0),
                                playoffPlayersPerSide = (ePlayoffPlayers.toIntOrNull() ?: 0).coerceAtLeast(0),
                                playoffSquadSize = (ePlayoffSquad.toIntOrNull() ?: 0).coerceAtLeast(0),
                                playoffOvers = (ePlayoffOvers.toIntOrNull() ?: 0).coerceAtLeast(0),
                                finalPlayersPerSide = (eFinalPlayers.toIntOrNull() ?: 0).coerceAtLeast(0),
                                finalSquadSize = (eFinalSquad.toIntOrNull() ?: 0).coerceAtLeast(0),
                                finalOvers = (eFinalOvers.toIntOrNull() ?: 0).coerceAtLeast(0),
                                mottBattingWeight = (eMottBat.toDoubleOrNull() ?: tournament.mottBattingWeight).coerceAtLeast(0.0),
                                mottBowlingWeight = (eMottBowl.toDoubleOrNull() ?: tournament.mottBowlingWeight).coerceAtLeast(0.0),
                                mottBowlingWicketShare = (eMottWktShare.toDoubleOrNull() ?: tournament.mottBowlingWicketShare).coerceAtLeast(0.0),
                                mottBowlingEconomyShare = (eMottEconShare.toDoubleOrNull() ?: tournament.mottBowlingEconomyShare).coerceAtLeast(0.0),
                                mottFinalMultiplier = (eMottFinalMult.toDoubleOrNull() ?: tournament.mottFinalMultiplier).coerceAtLeast(1.0),
                                tiebreakerOrder = eTiebreakers.joinToString(",")
                            )
                        )
                        showEditRulesDialog = false
                    }) { Text(strings.save) }
                },
                dismissButton = {
                    TextButton(onClick = { showEditRulesDialog = false }) { Text(strings.cancel) }
                }
            )
        }
    }
}

@Composable
private fun HubTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
